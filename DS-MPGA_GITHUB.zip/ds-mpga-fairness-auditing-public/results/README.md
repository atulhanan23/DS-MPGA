# Retained experimental evidence

`validated/` contains frozen aggregate and rule-level records. `validated_manifest.json` checks their hashes. `summary/` maps manuscript tables to source evidence and retains original numerical table bodies. These saved records are not newly executed experiments. Person-level data and trained models are not redistributed.

`outputs/` is reserved for newly executed demonstrations, summaries and experiments and is ignored by Git. Never overwrite validated evidence with a new run.
