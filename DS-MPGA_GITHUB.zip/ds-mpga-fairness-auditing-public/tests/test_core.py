import unittest
import numpy as np
import pandas as pd
from src.rules.processing import decode, classify
from src.evaluation.cache import RuleCache
from src.evaluation.conditional import conditional_metrics
from src.algorithms.ds_mpga import run_ds_mpga_v3_ablation, run_ds_mpga_v3_cached
from src.baselines.exact_random import enumerate_scores
from src.statistics.paired import paired
from scripts.demo import fixture
from src.preprocessing.paths import prediction_path
from pathlib import Path


class CoreTests(unittest.TestCase):
    def test_recorded_paths(self):
        self.assertEqual(prediction_path(Path('inputs'), r'prepared_data\a.csv'), Path('inputs/prepared_data/a.csv'))
        with self.assertRaises(ValueError):
            prediction_path(Path('inputs'), '../outside.csv')

    def test_decode_and_intersection(self):
        self.assertEqual(decode(["b = 1", "a = 0"]), (("a", "0"), ("b", "1")))
        with self.assertRaises(ValueError):
            decode(["a = 0", "a = 1"])
        self.assertFalse(classify(["a = 1", "c = 1"], ["a", "b"])["is_intersectional"])
        self.assertEqual(
            classify(["a = 1", "b = 1", "c = 0"], ["a", "b"])["category"],
            "intersection containing context",
        )

    def test_support_and_cache(self):
        data = pd.DataFrame(
            {"a": [0, 0, 1, 1], "b": [0, 1, 0, 1], "prediction": [0, 0, 1, 1]}
        )
        cache = RuleCache(data, ["a", "b"], 0.5)
        score = cache.evaluate(["a = 1"])
        self.assertEqual(score["support"], 0.5)
        self.assertEqual(score["discrepancy_score"], 1.0)
        self.assertIsNone(cache.evaluate(["a = 1", "b = 1"]))
        self.assertIsNone(cache.evaluate(["b = 1", "a = 1"]))
        self.assertEqual((cache.requests, cache.hits, len(cache.cache)), (3, 1, 2))
        with self.assertRaises(ValueError):
            cache.evaluate(["prediction = 1"])
        data.loc[:, "prediction"] = 0
        self.assertEqual(cache.evaluate(["a = 1"])["discrepancy_score"], 1.0)

    def test_empty_complement_and_undefined_metrics(self):
        data = pd.DataFrame({"a": [1, 1], "prediction": [0, 1]})
        self.assertIsNone(RuleCache(data, ["a"]).evaluate(["a = 1"]))
        metrics = conditional_metrics(
            np.ones(4), np.zeros(4), np.array([1, 1, 0, 0], bool)
        )
        self.assertEqual(metrics["tpr_gap"], 0.0)
        self.assertTrue(np.isnan(metrics["fpr_gap"]))
        self.assertTrue(np.isnan(metrics["equalized_odds_gap"]))

    def test_cached_uncached_and_canonical_parity(self):
        data = fixture()
        outputs = []
        for caching in [True, False]:
            outputs.append(
                run_ds_mpga_v3_ablation(
                    data, ["a", "b", "c"], random_state=11, use_cache=caching
                )
            )
        outputs.append(run_ds_mpga_v3_cached(data, ["a", "b", "c"], random_state=11))
        for output in outputs:
            self.assertEqual(output["total_evaluation_requests"], 5400)
            self.assertEqual(output["actual_evaluations"] + output["cache_hits"], 5400)
            for key in [
                "max_itemset",
                "min_itemset",
                "max_discrepancy_score",
                "min_discrepancy_score",
            ]:
                self.assertEqual(output[key], outputs[0][key])
        self.assertEqual(outputs[1]["cache_hits"], 0)

    def test_exact_space(self):
        rules, scores = enumerate_scores(fixture(), ["a", "b", "c"])
        self.assertEqual(len(rules), 26)
        self.assertEqual(len(set(rules)), 26)
        self.assertEqual(np.nanmax(scores), 1.0)
        self.assertEqual(np.nanmin(scores), 0.0)

    def test_zero_differences(self):
        output = paired(pd.Series([1.0, 1.0]), pd.Series([1.0, 1.0]))
        self.assertEqual(output["n_nonzero"], 0)
        self.assertEqual(output["p_raw"], 1.0)
        self.assertEqual(output["rank_biserial"], 0.0)


if __name__ == "__main__":
    unittest.main()
