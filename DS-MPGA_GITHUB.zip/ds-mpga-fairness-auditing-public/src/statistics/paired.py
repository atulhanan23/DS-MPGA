import numpy as np
from scipy.stats import wilcoxon, rankdata


def paired(first, second):
    joined = first.rename("a").to_frame().join(second.rename("b"), how="inner").dropna()
    assert len(joined) == len(first.dropna()) == len(second.dropna())
    delta = np.round(joined.a.to_numpy() - joined.b.to_numpy(), 12)
    nz = delta[delta != 0]
    if len(nz) == 0:
        stat, p, effect = 0.0, 1.0, 0.0
    else:
        test = wilcoxon(
            delta, zero_method="wilcox", alternative="two-sided", method="asymptotic"
        )
        stat, p = float(test.statistic), float(test.pvalue)
        ranks = rankdata(abs(nz))
        effect = float((ranks[nz > 0].sum() - ranks[nz < 0].sum()) / ranks.sum())
    med = float(np.median(delta))
    return {
        "n_pairs": len(joined),
        "n_nonzero": len(nz),
        "statistic": stat,
        "p_raw": p,
        "first_median": float(joined.a.median()),
        "second_median": float(joined.b.median()),
        "median_paired_difference": med,
        "mean_paired_difference": float(delta.mean()),
        "rank_biserial": effect,
        "direction": (
            "first larger"
            if med > 0
            else "second larger" if med < 0 else "median difference zero"
        ),
    }
