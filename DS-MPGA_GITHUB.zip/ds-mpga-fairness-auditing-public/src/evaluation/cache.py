"""Validated public evaluation interface; the historical search uses its own scorer."""

from src.rules.processing import decode
from src.algorithms.ds_mpga import calculate_subgroup_metrics_v2


class RuleCache:
    def __init__(self, table, attributes, min_support=0.1):
        if not 0 <= min_support <= 1:
            raise ValueError("Support must lie in [0, 1].")
        if (
            table.empty
            or table["prediction"].isna().any()
            or not set(table.prediction.unique()) <= {0, 1}
        ):
            raise ValueError("A nonempty table with binary predictions is required.")
        self.table = table.copy(deep=True)
        self.attributes = set(attributes)
        self.min_support = min_support
        self.cache = {}
        self.requests = self.hits = 0

    def evaluate(self, rule):
        conditions = decode(rule)
        if len(conditions) > 3 or not {a for a, _ in conditions} <= self.attributes:
            raise ValueError(
                "Rule exceeds the declared attribute or length constraints."
            )
        key = tuple(f"{a} = {v}" for a, v in conditions)
        self.requests += 1
        if key in self.cache:
            self.hits += 1
        else:
            self.cache[key] = calculate_subgroup_metrics_v2(
                self.table, key, min_support=self.min_support
            )
        result = self.cache[key]
        return None if result is None else dict(result)
