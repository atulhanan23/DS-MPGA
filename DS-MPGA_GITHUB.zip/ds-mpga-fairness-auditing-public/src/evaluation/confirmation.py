import numpy as np


def evaluate_fixed(table, rule):
    mask = np.ones(len(table), bool)
    for item in rule:
        attr, value = item.split(" = ", 1)
        mask &= table[attr].astype(str).to_numpy() == value
    inside = int(mask.sum())
    outside = len(table) - inside
    a = float(table.loc[mask, "prediction"].mean()) if inside else np.nan
    b = float(table.loc[~mask, "prediction"].mean()) if outside else np.nan
    return {
        "support": inside / len(table),
        "inside_n": inside,
        "outside_n": outside,
        "signed_difference": a - b,
        "cv": abs(a - b),
        "defined": bool(inside and outside),
        "support_ok": bool(inside / len(table) >= 0.1),
    }
