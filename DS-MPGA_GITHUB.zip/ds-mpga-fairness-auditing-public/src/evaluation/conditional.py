import numpy as np


def conditional_metrics(y, p, mask):
    result = {}
    for label, m in [("subgroup", mask), ("outside", ~mask)]:
        yy, pp = y[m], p[m]
        counts = {
            "tp": int(((yy == 1) & (pp == 1)).sum()),
            "fp": int(((yy == 0) & (pp == 1)).sum()),
            "tn": int(((yy == 0) & (pp == 0)).sum()),
            "fn": int(((yy == 1) & (pp == 0)).sum()),
        }
        result.update({f"{label}_{k}": v for k, v in counts.items()})
        for metric, den in [
            ("tpr", counts["tp"] + counts["fn"]),
            ("fpr", counts["fp"] + counts["tn"]),
            ("ppv", counts["tp"] + counts["fp"]),
        ]:
            num = counts["fp"] if metric == "fpr" else counts["tp"]
            result[f"{label}_{metric}"] = num / den if den else np.nan
            result[f"{label}_{metric}_denominator"] = den
    for metric in ["tpr", "fpr", "ppv"]:
        a, b = result[f"subgroup_{metric}"], result[f"outside_{metric}"]
        reason = "; ".join(
            f"{side} denominator is zero"
            for side in ["subgroup", "outside"]
            if result[f"{side}_{metric}_denominator"] == 0
        )
        result[f"{metric}_gap_reason"] = reason
        result[f"{metric}_signed_difference"] = a - b if not reason else np.nan
        result[f"{metric}_gap"] = abs(a - b) if not reason else np.nan
    reasons = [
        result[f"{m}_gap_reason"] for m in ["tpr", "fpr"] if result[f"{m}_gap_reason"]
    ]
    result["equalized_odds_gap"] = (
        max(result["tpr_gap"], result["fpr_gap"]) if not reasons else np.nan
    )
    result["equalized_odds_gap_reason"] = "; ".join(reasons)
    return result
