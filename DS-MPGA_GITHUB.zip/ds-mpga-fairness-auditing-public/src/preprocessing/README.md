# Modeling inputs

The retained preparation implementation is `scripts/run_xgboost.py::prepare` and is shared by the four classifier drivers. It explicitly removes outcome and label columns before encoding predictors. The favorable outcome is income above 50K for Adult, no two-year recidivism for COMPAS, and good credit for German Credit.

The archived protocol forms the dummy-category vocabulary before the split. Numeric scaling for logistic regression is fitted on training rows only. This vocabulary choice is disclosed in the manuscript; changing it would create a different experiment version.

The full workflow starts from prepared modeling tables. Provider-level snapshots and the original historical Adult/German fixed-RF training indices are unavailable. See `data/README.md` for the required schemas and source links. No reconstructed raw-to-prepared pipeline is passed off as the historical one.
