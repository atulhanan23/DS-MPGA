"""Resolve relative provenance paths saved on either Windows or POSIX."""
from pathlib import Path, PureWindowsPath


def prediction_path(root, recorded):
    value = PureWindowsPath(str(recorded))
    if value.is_absolute() or value.drive or '..' in value.parts:
        raise ValueError('Prediction provenance must use a relative path within the input workspace.')
    return Path(root).joinpath(*value.parts)
