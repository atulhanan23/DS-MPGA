"""Finite-space reference and uniform, distinct-rule random baseline."""

import itertools
import numpy as np
from src.algorithms.ds_mpga import calculate_subgroup_metrics_v2


def enumerate_scores(table, attributes, max_length=3, min_support=0.1):
    rules, scores = [], []
    for length in range(1, max_length + 1):
        for subset in itertools.combinations(attributes, length):
            levels = [sorted(table[a].dropna().astype(str).unique()) for a in subset]
            for values in itertools.product(*levels):
                rule = tuple(sorted(f"{a} = {v}" for a, v in zip(subset, values)))
                result = calculate_subgroup_metrics_v2(
                    table, rule, min_support=min_support
                )
                rules.append(rule)
                scores.append(np.nan if result is None else result["discrepancy_score"])
    return rules, np.asarray(scores)


def uniform_random_reference(rules, scores, budget, seed):
    if budget < 1:
        raise ValueError("Budget must be positive.")
    indices = np.random.default_rng(seed).choice(
        len(rules), min(budget, len(rules)), replace=False
    )
    valid = indices[np.isfinite(scores[indices])]
    if not len(valid):
        return dict(max_rule=None, min_rule=None, requests=len(indices))
    high, low = valid[np.argmax(scores[valid])], valid[np.argmin(scores[valid])]
    return dict(
        max_rule=rules[high],
        min_rule=rules[low],
        max_cv=float(scores[high]),
        min_cv=float(scores[low]),
        requests=len(indices),
    )
