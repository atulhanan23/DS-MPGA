# Baseline scope

The actual finite-space exact enumeration and matched-work random search are in `scripts/run_journal_extension.py`. The controlled-scaling random search and hill climbing are in `scripts/run_large_space.py`. Their proposal distributions differ as described in the manuscript.

`exact_random.py` is an auxiliary finite-fixture checker used by the tests and smoke demonstration. It is not represented as the historical benchmark driver. The retained engine exposes the actual single-population, migration, cache and Max-only ablations. No unvalidated GA, PSO, GWO or Apriori comparison is manufactured.
