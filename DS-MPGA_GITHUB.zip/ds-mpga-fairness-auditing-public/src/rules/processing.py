"""Decode canonical conjunctions and describe audit-attribute membership."""

import json


def decode(rule):
    if isinstance(rule, str):
        rule = json.loads(rule) if rule.lstrip().startswith("[") else rule.split(", ")
    conditions = []
    seen = set()
    for item in rule:
        if " = " not in item:
            raise ValueError(f"Malformed condition: {item!r}")
        attribute, value = item.split(" = ", 1)
        if not attribute or attribute in seen:
            raise ValueError("Each rule must contain distinct, nonempty attributes.")
        seen.add(attribute)
        conditions.append((attribute, value))
    if not conditions:
        raise ValueError("A rule must contain at least one condition.")
    return tuple(sorted(conditions))


def classify(rule, audit_attributes):
    attributes = {a for a, _ in decode(rule)}
    audit = attributes & set(audit_attributes)
    context = attributes - audit
    category = (
        "contextual"
        if not audit
        else (
            "single audit attribute"
            if len(audit) == 1 and not context
            else (
                "mixed non-intersection"
                if len(audit) == 1
                else (
                    "audit-only intersection"
                    if not context
                    else "intersection containing context"
                )
            )
        )
    )
    return dict(
        category=category,
        audit_attributes=sorted(audit),
        context_attributes=sorted(context),
        is_intersectional=len(audit) >= 2,
    )
