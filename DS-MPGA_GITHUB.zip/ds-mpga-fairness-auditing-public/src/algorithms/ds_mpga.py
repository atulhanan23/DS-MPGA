import random
import time
import itertools
import numpy as np
import pandas as pd


def get_attribute_from_item(item):
    return str(item).split(" = ")[0]


def calculate_subgroup_metrics_v2(
    results_df, itemset, prediction_col="prediction", min_support=0.1
):
    """
    Compute subgroup support and CV/discrepancy score.
    CV(S) = |P(yhat=1 | S) - P(yhat=1 | not S)|
    """
    if isinstance(itemset, str):
        itemset = [itemset]
    subgroup_mask = pd.Series(True, index=results_df.index)
    for item in itemset:
        if " = " not in str(item):
            return None
        attr, value = str(item).split(" = ", 1)
        if attr not in results_df.columns:
            return None
        subgroup_mask = subgroup_mask & (results_df[attr].astype(str) == str(value))
    support = subgroup_mask.mean()
    if support < min_support:
        return None
    outside_mask = ~subgroup_mask
    if subgroup_mask.sum() == 0 or outside_mask.sum() == 0:
        return None
    subgroup_rate = results_df.loc[subgroup_mask, prediction_col].mean()
    outside_rate = results_df.loc[outside_mask, prediction_col].mean()
    discrepancy_score = abs(subgroup_rate - outside_rate)
    return {
        "support": support,
        "metric_subgroup": subgroup_rate,
        "metric_outside": outside_rate,
        "discrepancy_score": discrepancy_score,
    }


def create_candidate_items(results_df, subgroup_attributes):
    """
    Create all possible attribute-value items.
    Example: sex = Female
    """
    candidate_items = []
    for attr in subgroup_attributes:
        values = results_df[attr].dropna().astype(str).unique().tolist()
        for value in values:
            candidate_items.append(f"{attr} = {value}")
    return candidate_items


def repair_itemset_v2(itemset, max_length=3):
    """
    Remove duplicate attributes inside one subgroup rule.
    Example invalid:
    age_group = 18 to 25 AND age_group = 36 to 50
    """
    repaired = []
    used_attrs = set()
    random.shuffle(itemset)
    for item in itemset:
        attr = get_attribute_from_item(item)
        if attr not in used_attrs:
            repaired.append(item)
            used_attrs.add(attr)
        if len(repaired) >= max_length:
            break
    return repaired


def create_random_itemset_v2(candidate_items, min_length=1, max_length=3):
    length = random.randint(min_length, max_length)
    sampled = random.sample(candidate_items, min(length, len(candidate_items)))
    return repair_itemset_v2(sampled, max_length=max_length)


def evaluate_itemset_v2(
    results_df, itemset, cache, prediction_col="prediction", min_support=0.1
):
    """
    Cached subgroup evaluation.
    """
    itemset = repair_itemset_v2(list(itemset), max_length=3)
    key = tuple(sorted(itemset))
    if key in cache:
        return (cache[key], True)
    metrics = calculate_subgroup_metrics_v2(
        results_df=results_df,
        itemset=list(key),
        prediction_col=prediction_col,
        min_support=min_support,
    )
    cache[key] = metrics
    return (metrics, False)


def crossover_itemsets(parent1, parent2, max_length=3):
    combined = list(parent1) + list(parent2)
    random.shuffle(combined)
    child = repair_itemset_v2(combined, max_length=max_length)
    if len(child) == 0:
        child = list(parent1)
    return child


def mutate_itemset(itemset, candidate_items, mutation_rate=0.3, max_length=3):
    itemset = list(itemset)
    if random.random() < mutation_rate:
        mutation_type = random.choice(["replace", "add", "remove"])
        if mutation_type == "replace" and len(itemset) > 0:
            idx = random.randint(0, len(itemset) - 1)
            itemset[idx] = random.choice(candidate_items)
        elif mutation_type == "add" and len(itemset) < max_length:
            itemset.append(random.choice(candidate_items))
        elif mutation_type == "remove" and len(itemset) > 1:
            idx = random.randint(0, len(itemset) - 1)
            itemset.pop(idx)
    return repair_itemset_v2(itemset, max_length=max_length)


def run_ds_mpga_v3_cached(
    results_df,
    subgroup_attributes,
    random_state=42,
    prediction_col="prediction",
    min_support=0.1,
    max_length=3,
    n_populations=3,
    population_size=30,
    generations=30,
    mutation_rate=0.3,
    migration_interval=5,
    migration_size=3,
):
    """
    DS-MPGA v3 Cached:
    - multi-population GA
    - dual search:
      1. max-CV populations search high-discrepancy subgroups
      2. min-CV populations search low-discrepancy valid subgroups
    - cached subgroup evaluation
    """
    random.seed(random_state)
    np.random.seed(random_state)
    start_time = time.time()
    candidate_items = create_candidate_items(results_df, subgroup_attributes)
    cache = {}
    total_evaluation_requests = 0
    actual_evaluations = 0
    cache_hits = 0
    max_populations = [
        [
            create_random_itemset_v2(candidate_items, 1, max_length)
            for _ in range(population_size)
        ]
        for _ in range(n_populations)
    ]
    min_populations = [
        [
            create_random_itemset_v2(candidate_items, 1, max_length)
            for _ in range(population_size)
        ]
        for _ in range(n_populations)
    ]
    best_max = None
    best_min = None

    def evaluate_population(population):
        nonlocal total_evaluation_requests, actual_evaluations, cache_hits
        evaluated = []
        for itemset in population:
            total_evaluation_requests += 1
            metrics, hit = evaluate_itemset_v2(
                results_df=results_df,
                itemset=itemset,
                cache=cache,
                prediction_col=prediction_col,
                min_support=min_support,
            )
            if hit:
                cache_hits += 1
            else:
                actual_evaluations += 1
            if metrics is not None:
                evaluated.append(
                    {
                        "itemset": tuple(
                            sorted(repair_itemset_v2(itemset, max_length=max_length))
                        ),
                        **metrics,
                    }
                )
        return evaluated

    for gen in range(generations):
        for p_idx in range(n_populations):
            evaluated = evaluate_population(max_populations[p_idx])
            if len(evaluated) == 0:
                max_populations[p_idx] = [
                    create_random_itemset_v2(candidate_items, 1, max_length)
                    for _ in range(population_size)
                ]
                continue
            evaluated = sorted(
                evaluated, key=lambda x: x["discrepancy_score"], reverse=True
            )
            if (
                best_max is None
                or evaluated[0]["discrepancy_score"] > best_max["discrepancy_score"]
            ):
                best_max = evaluated[0]
            parents = evaluated[: max(2, population_size // 2)]
            new_population = [list(x["itemset"]) for x in parents[:migration_size]]
            while len(new_population) < population_size:
                parent1 = list(random.choice(parents)["itemset"])
                parent2 = list(random.choice(parents)["itemset"])
                child = crossover_itemsets(parent1, parent2, max_length=max_length)
                child = mutate_itemset(
                    child,
                    candidate_items,
                    mutation_rate=mutation_rate,
                    max_length=max_length,
                )
                new_population.append(child)
            max_populations[p_idx] = new_population
        for p_idx in range(n_populations):
            evaluated = evaluate_population(min_populations[p_idx])
            if len(evaluated) == 0:
                min_populations[p_idx] = [
                    create_random_itemset_v2(candidate_items, 1, max_length)
                    for _ in range(population_size)
                ]
                continue
            evaluated = sorted(
                evaluated, key=lambda x: x["discrepancy_score"], reverse=False
            )
            if (
                best_min is None
                or evaluated[0]["discrepancy_score"] < best_min["discrepancy_score"]
            ):
                best_min = evaluated[0]
            parents = evaluated[: max(2, population_size // 2)]
            new_population = [list(x["itemset"]) for x in parents[:migration_size]]
            while len(new_population) < population_size:
                parent1 = list(random.choice(parents)["itemset"])
                parent2 = list(random.choice(parents)["itemset"])
                child = crossover_itemsets(parent1, parent2, max_length=max_length)
                child = mutate_itemset(
                    child,
                    candidate_items,
                    mutation_rate=mutation_rate,
                    max_length=max_length,
                )
                new_population.append(child)
            min_populations[p_idx] = new_population
        if (gen + 1) % migration_interval == 0:
            for populations in [max_populations, min_populations]:
                migrants = []
                for p in populations:
                    migrants.extend(random.sample(p, min(migration_size, len(p))))
                random.shuffle(migrants)
                for p_idx, p in enumerate(populations):
                    replace_count = min(migration_size, len(p), len(migrants))
                    p[:replace_count] = migrants[:replace_count]
    end_time = time.time()
    if best_max is None or best_min is None:
        return {
            "max_discrepancy_score": np.nan,
            "min_discrepancy_score": np.nan,
            "discrepancy_gap": np.nan,
            "total_evaluation_requests": total_evaluation_requests,
            "actual_evaluations": actual_evaluations,
            "cache_hits": cache_hits,
            "cache_hit_rate": (
                cache_hits / total_evaluation_requests
                if total_evaluation_requests > 0
                else np.nan
            ),
            "runtime_seconds": end_time - start_time,
            "runtime_minutes": (end_time - start_time) / 60,
        }
    return {
        "max_itemset": ", ".join(best_max["itemset"]),
        "max_support": best_max["support"],
        "max_metric_subgroup": best_max["metric_subgroup"],
        "max_metric_outside": best_max["metric_outside"],
        "max_discrepancy_score": best_max["discrepancy_score"],
        "min_itemset": ", ".join(best_min["itemset"]),
        "min_support": best_min["support"],
        "min_metric_subgroup": best_min["metric_subgroup"],
        "min_metric_outside": best_min["metric_outside"],
        "min_discrepancy_score": best_min["discrepancy_score"],
        "discrepancy_gap": best_max["discrepancy_score"]
        - best_min["discrepancy_score"],
        "total_evaluation_requests": total_evaluation_requests,
        "actual_evaluations": actual_evaluations,
        "cache_hits": cache_hits,
        "cache_hit_rate": (
            cache_hits / total_evaluation_requests
            if total_evaluation_requests > 0
            else np.nan
        ),
        "runtime_seconds": end_time - start_time,
        "runtime_minutes": (end_time - start_time) / 60,
    }


import os
import random
import time
import numpy as np
import pandas as pd


def run_ds_mpga_v3_ablation(
    results_df,
    subgroup_attributes,
    random_state=42,
    prediction_col="prediction",
    min_support=0.1,
    max_length=3,
    n_populations=3,
    population_size=30,
    generations=30,
    mutation_rate=0.3,
    migration_interval=5,
    migration_size=3,
    use_cache=True,
    enable_migration=True,
    dual_search=True,
):
    """Configurable DS-MPGA runner used only for controlled ablations."""
    random.seed(random_state)
    np.random.seed(random_state)
    start_time = time.time()
    candidate_items = create_candidate_items(results_df, subgroup_attributes)
    if not candidate_items:
        raise ValueError("No candidate subgroup items were created.")
    cache = {}
    total_evaluation_requests = 0
    actual_evaluations = 0
    cache_hits = 0

    def evaluate_one(itemset):
        nonlocal total_evaluation_requests, actual_evaluations, cache_hits
        total_evaluation_requests += 1
        repaired = repair_itemset_v2(list(itemset), max_length=max_length)
        key = tuple(sorted(repaired))
        if use_cache and key in cache:
            cache_hits += 1
            return cache[key]
        metrics = calculate_subgroup_metrics_v2(
            results_df=results_df,
            itemset=list(key),
            prediction_col=prediction_col,
            min_support=min_support,
        )
        actual_evaluations += 1
        if use_cache:
            cache[key] = metrics
        return metrics

    def evaluate_population(population):
        evaluated = []
        for itemset in population:
            metrics = evaluate_one(itemset)
            if metrics is not None:
                evaluated.append(
                    {
                        "itemset": tuple(
                            sorted(repair_itemset_v2(itemset, max_length=max_length))
                        ),
                        **metrics,
                    }
                )
        return evaluated

    def initialize_populations():
        return [
            [
                create_random_itemset_v2(candidate_items, 1, max_length)
                for _ in range(population_size)
            ]
            for _ in range(n_populations)
        ]

    def evolve_population(population, objective):
        evaluated = evaluate_population(population)
        if not evaluated:
            replacement = [
                create_random_itemset_v2(candidate_items, 1, max_length)
                for _ in range(population_size)
            ]
            return (replacement, None)
        reverse = objective == "max"
        evaluated.sort(key=lambda x: x["discrepancy_score"], reverse=reverse)
        generation_best = evaluated[0]
        parents = evaluated[: max(2, population_size // 2)]
        elite_count = min(migration_size, len(parents), population_size)
        new_population = [list(x["itemset"]) for x in parents[:elite_count]]
        while len(new_population) < population_size:
            parent1 = list(random.choice(parents)["itemset"])
            parent2 = list(random.choice(parents)["itemset"])
            child = crossover_itemsets(parent1, parent2, max_length=max_length)
            child = mutate_itemset(
                child,
                candidate_items,
                mutation_rate=mutation_rate,
                max_length=max_length,
            )
            new_population.append(child)
        return (new_population, generation_best)

    max_populations = initialize_populations()
    min_populations = initialize_populations() if dual_search else []
    best_max = None
    best_min = None
    for generation in range(generations):
        for p_idx in range(n_populations):
            max_populations[p_idx], candidate = evolve_population(
                max_populations[p_idx], "max"
            )
            if candidate is not None and (
                best_max is None
                or candidate["discrepancy_score"] > best_max["discrepancy_score"]
            ):
                best_max = candidate
        if dual_search:
            for p_idx in range(n_populations):
                min_populations[p_idx], candidate = evolve_population(
                    min_populations[p_idx], "min"
                )
                if candidate is not None and (
                    best_min is None
                    or candidate["discrepancy_score"] < best_min["discrepancy_score"]
                ):
                    best_min = candidate
        should_migrate = (
            enable_migration
            and n_populations > 1
            and (migration_interval is not None)
            and (migration_interval > 0)
            and ((generation + 1) % migration_interval == 0)
        )
        if should_migrate:
            population_sets = [max_populations]
            if dual_search:
                population_sets.append(min_populations)
            for populations in population_sets:
                migrants = []
                for population in populations:
                    migrants.extend(
                        random.sample(population, min(migration_size, len(population)))
                    )
                random.shuffle(migrants)
                for population in populations:
                    replace_count = min(migration_size, len(population), len(migrants))
                    population[:replace_count] = migrants[:replace_count]
    elapsed = time.time() - start_time
    output = {
        "max_itemset": "" if best_max is None else ", ".join(best_max["itemset"]),
        "max_support": np.nan if best_max is None else best_max["support"],
        "max_metric_subgroup": (
            np.nan if best_max is None else best_max["metric_subgroup"]
        ),
        "max_metric_outside": (
            np.nan if best_max is None else best_max["metric_outside"]
        ),
        "max_discrepancy_score": (
            np.nan if best_max is None else best_max["discrepancy_score"]
        ),
        "min_itemset": "" if best_min is None else ", ".join(best_min["itemset"]),
        "min_support": np.nan if best_min is None else best_min["support"],
        "min_metric_subgroup": (
            np.nan if best_min is None else best_min["metric_subgroup"]
        ),
        "min_metric_outside": (
            np.nan if best_min is None else best_min["metric_outside"]
        ),
        "min_discrepancy_score": (
            np.nan if best_min is None else best_min["discrepancy_score"]
        ),
        "total_evaluation_requests": total_evaluation_requests,
        "actual_evaluations": actual_evaluations,
        "cache_hits": cache_hits,
        "cache_hit_rate": (
            cache_hits / total_evaluation_requests
            if total_evaluation_requests
            else np.nan
        ),
        "runtime_seconds": elapsed,
        "runtime_minutes": elapsed / 60,
    }
    output["discrepancy_gap"] = (
        output["max_discrepancy_score"] - output["min_discrepancy_score"]
        if pd.notna(output["max_discrepancy_score"])
        and pd.notna(output["min_discrepancy_score"])
        else np.nan
    )
    return output
