import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import json
import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import NullLocator, NullFormatter


def main():
    out = ROOT / "results/large_space_v1/full"
    df = pd.read_csv(out / "details.csv")
    assert json.loads((out / "validation.json").read_text())["status"] == "passed"
    metrics = [
        "max_cv",
        "min_cv",
        "actual_evaluations",
        "cache_hits",
        "runtime_seconds",
        "reference_gap",
        "max_regret_lower",
        "max_regret_upper",
        "min_regret",
    ]
    units = (
        df.groupby(["landscape", "dimensions", "data_seed", "method", "budget"])[
            metrics
        ]
        .mean()
        .reset_index()
    )
    units.to_csv(out / "per_table.csv", index=False)
    summary = (
        units.groupby(["landscape", "dimensions", "method", "budget"])[metrics]
        .agg(["mean", "std"])
        .reset_index()
    )
    summary.columns = [
        "_".join(x).rstrip("_") if isinstance(x, tuple) else x for x in summary.columns
    ]
    summary.to_csv(out / "summary.csv", index=False)
    rng = np.random.default_rng(92741)
    pairs = []
    for (land, d, b), g in units.groupby(["landscape", "dimensions", "budget"]):
        pivot = g.pivot(index="data_seed", columns="method", values="max_cv")
        for baseline in ["Random", "Hill climb"]:
            delta = (pivot["DS-MPGA"] - pivot[baseline]).to_numpy()
            boot = delta[rng.integers(0, len(delta), size=(10000, len(delta)))].mean(
                axis=1
            )
            pairs.append(
                {
                    "landscape": land,
                    "dimensions": d,
                    "budget": b,
                    "comparison": "DS-MPGA minus " + baseline,
                    "mean_difference": delta.mean(),
                    "ci_low": np.quantile(boot, 0.025),
                    "ci_high": np.quantile(boot, 0.975),
                    "data_tables": len(delta),
                    "note": "Descriptive table-level percentile bootstrap, no multiplicity-adjusted significance claim.",
                }
            )
    pd.DataFrame(pairs).to_csv(out / "paired_differences.csv", index=False)
    latest = summary[summary.budget.eq(5400)]
    print(
        latest[
            [
                "landscape",
                "dimensions",
                "method",
                "max_cv_mean",
                "runtime_seconds_mean",
                "actual_evaluations_mean",
            ]
        ].to_string(index=False)
    )
    fig, axes = plt.subplots(2, 4, figsize=(14, 6.5), sharex=True, sharey="row")
    colors = {"DS-MPGA": "#225a93", "Random": "#ba681c", "Hill climb": "#367c4a"}
    for row, land in enumerate(["conjunction", "parity"]):
        for col, d in enumerate([16, 64, 256, 1024]):
            ax = axes[row, col]
            for method in colors:
                subset = summary.query(
                    "landscape == @land and dimensions == @d and method == @method"
                ).sort_values("budget")
                ax.plot(
                    subset.budget,
                    subset.max_cv_mean,
                    marker="o",
                    label=method,
                    color=colors[method],
                )
            reference = df.query(
                "landscape == @land and dimensions == @d"
            ).subset_max.mean()
            ax.axhline(
                reference,
                color="gray",
                linestyle="--",
                linewidth=1,
                label="Restricted exact" if row == 0 and col == 0 else None,
            )
            ax.set_title(f"{land.capitalize()}, d={d}", fontsize=13)
            ax.grid(alpha=0.2)
            ax.set_xscale("log")
            ax.set_xticks([540, 1800, 5400], ["540", "1,800", "5,400"], fontsize=12)
            ax.xaxis.set_minor_locator(NullLocator())
            ax.xaxis.set_minor_formatter(NullFormatter())
            ax.tick_params(axis="y", labelsize=12)
            if col == 0:
                ax.set_ylabel("Mean maximum CV", fontsize=12)
            if row == 1:
                ax.set_xlabel("Evaluation requests", fontsize=12)
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="lower center",
        ncol=4,
        bbox_to_anchor=(0.5, -0.01),
        fontsize=12,
    )
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    dest = ROOT / "figures/large_space_v1"
    dest.mkdir(parents=True, exist_ok=True)
    for ext in ["png", "svg"]:
        fig.savefig(dest / f"large_space_results.{ext}", dpi=220, bbox_inches="tight")
    plt.close(fig)
    overview = {
        "method_trajectories": len(df) // 3,
        "budget_records": len(df),
        "data_tables": 80,
        "largest_rule_space": int(df.rule_space.max()),
        "largest_request_fraction": float(
            df.query("dimensions == 1024 and budget == 5400").request_space_ratio.iloc[
                0
            ]
        ),
        "global_regret_certified_records": int(df.global_max_certified.sum()),
        "bounded_regret_records": int((~df.global_max_certified).sum()),
        "minimum_reference_gap": float(df.reference_gap.min()),
    }
    (out / "overview.json").write_text(json.dumps(overview, indent=2))
    print(json.dumps(overview, indent=2))


if __name__ == "__main__":
    main()
