"""Aligned-request-budget synthetic stress test, with certified regret bounds."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import argparse, hashlib, itertools, json, math, random, time
import numpy as np
import pandas as pd
from src.algorithms import ds_mpga as engine

BUDGETS = [540, 1800, 5400]


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def bits(a):
    return int.from_bytes(np.packbits(a, bitorder="little").tobytes(), "little")


def generate(d, rep, landscape):
    rng = np.random.default_rng(70000 + rep * 10000 + d)
    strata = np.repeat(np.arange(8), 1024)
    x = np.empty((8192, d), dtype=np.uint8)
    for j in range(3):
        x[:, j] = (strata >> j) & 1
    balanced = np.repeat([0, 1], 512).astype(np.uint8)
    for j in range(3, d):
        for s in range(8):
            x[s * 1024 : (s + 1) * 1024, j] = rng.permutation(balanced)
    permutation = rng.permutation(d)
    signal = [int(np.flatnonzero(permutation == i)[0]) for i in range(3)]
    y = (
        (strata == 7).astype(np.uint8)
        if landscape == "conjunction"
        else ((x[:, :3].sum(axis=1) % 2) == 1).astype(np.uint8)
    )
    order = rng.permutation(len(x))
    x = x[order][:, permutation]
    y = y[order]
    attrs = [f"a{i:04d}" for i in range(d)]
    frame = pd.DataFrame(x, columns=attrs)
    frame["prediction"] = y
    return frame, attrs, signal, hashlib.sha256(x.tobytes() + y.tobytes()).hexdigest()


class Scorer:
    def __init__(self, frame, attrs):
        t = time.perf_counter()
        self.n = len(frame)
        self.all = (1 << self.n) - 1
        self.positive = bits(frame.prediction.to_numpy())
        self.total = self.positive.bit_count()
        self.masks = {
            f"{a} = {v}": bits(frame[a].to_numpy() == v) for a in attrs for v in [0, 1]
        }
        self.items = [
            f"{a} = {v}"
            for a in attrs
            for v in [int(frame[a].iloc[0]), 1 - int(frame[a].iloc[0])]
        ]
        self.setup_seconds = time.perf_counter() - t

    def metric(self, rule):
        mask = self.all
        for item in rule:
            mask &= self.masks[item]
        n = mask.bit_count()
        if n / self.n < 0.1 or n == self.n or n == 0:
            return None
        p = (mask & self.positive).bit_count()
        a = p / n
        b = (self.total - p) / (self.n - n)
        return {
            "support": n / self.n,
            "metric_subgroup": a,
            "metric_outside": b,
            "discrepancy_score": abs(a - b),
        }


def oracle(scorer, attrs):
    start = time.perf_counter()
    maximum = -1.0
    minimum = 2.0
    count = 0
    for k in range(1, 4):
        for subset in itertools.combinations(attrs, k):
            for values in itertools.product([0, 1], repeat=k):
                m = scorer.metric(tuple(f"{a} = {v}" for a, v in zip(subset, values)))
                count += 1
                if m:
                    maximum = max(maximum, m["discrepancy_score"])
                    minimum = min(minimum, m["discrepancy_score"])
    return maximum, minimum, count, time.perf_counter() - start


def run_method(method, frame, attrs, scorer, seed):
    random.seed(seed)
    np.random.seed(seed)
    cache = {}
    best = {"max": None, "min": None}
    records = []
    queries = 0
    start = time.perf_counter()

    def observe(rule, m, side):
        if m is not None and (
            best[side] is None
            or (
                m["discrepancy_score"] > best[side][1]["discrepancy_score"]
                if side == "max"
                else m["discrepancy_score"] < best[side][1]["discrepancy_score"]
            )
        ):
            best[side] = (tuple(sorted(rule)), m)

    def snapshot():
        record = {
            "budget": queries,
            "actual_evaluations": len(cache),
            "cache_hits": queries - len(cache),
            "runtime_seconds": time.perf_counter() - start,
        }
        for side in ["max", "min"]:
            assert best[side] is not None
            record[side + "_rule"] = json.dumps(best[side][0])
            record[side + "_cv"] = best[side][1]["discrepancy_score"]
        records.append(record)

    def query(rule, side):
        nonlocal queries
        rule = tuple(sorted(rule))
        queries += 1
        if rule not in cache:
            cache[rule] = scorer.metric(rule)
        m = cache[rule]
        observe(rule, m, side)
        if queries in BUDGETS:
            snapshot()
        return m

    if method == "DS-MPGA":
        original = engine.evaluate_itemset_v2
        original_items = engine.create_candidate_items

        def evaluator(results_df, itemset, cache, **kwargs):
            # Same stochastic repair as the canonical evaluator; scorer consumes no RNG.
            key = tuple(sorted(engine.repair_itemset_v2(list(itemset), max_length=3)))
            side = "max" if queries % 180 < 90 else "min"
            hit = key in cache
            m = query(key, side)
            cache[key] = m
            return m, hit

        engine.evaluate_itemset_v2 = evaluator
        engine.create_candidate_items = lambda *args, **kwargs: scorer.items.copy()
        try:
            result = engine.run_ds_mpga_v3_cached(frame, attrs, random_state=seed)
        finally:
            engine.evaluate_itemset_v2 = original
            engine.create_candidate_items = original_items
        assert queries == 5400 and result["actual_evaluations"] == len(cache)
        for side in best:
            assert np.isclose(
                result[side + "_discrepancy_score"],
                records[-1][side + "_cv"],
                atol=1e-12,
                rtol=0,
            )
    else:
        items = scorer.items.copy()
        chains = [None] * 6
        visits = [0] * 6
        for q in range(5400):
            chain = q % 6
            side = "max" if chain < 3 else "min"
            if method == "Random" or chains[chain] is None or visits[chain] % 100 == 0:
                rule = engine.create_random_itemset_v2(items, 1, 3)
            else:
                rule = engine.mutate_itemset(
                    chains[chain][0], items, mutation_rate=1.0, max_length=3
                )
            m = query(rule, side)
            visits[chain] += 1
            if method == "Hill climb" and m is not None:
                old = chains[chain]
                if (
                    old is None
                    or (visits[chain] - 1) % 100 == 0
                    or (
                        m["discrepancy_score"] >= old[1]
                        if side == "max"
                        else m["discrepancy_score"] <= old[1]
                    )
                ):
                    chains[chain] = (rule, m["discrepancy_score"])
    assert queries == 5400 and len(records) == 3
    return records


def test():
    frame, attrs, _, _ = generate(16, 999, "conjunction")
    frame = frame.iloc[:256].copy()
    scorer = Scorer(frame, attrs)
    assert scorer.items == engine.create_candidate_items(frame, attrs)
    for k in range(1, 4):
        for subset in itertools.combinations(attrs[:5], k):
            for values in itertools.product([0, 1], repeat=k):
                rule = [f"{a} = {v}" for a, v in zip(subset, values)]
                a = scorer.metric(rule)
                b = engine.calculate_subgroup_metrics_v2(frame, rule)
                assert (a is None) == (b is None)
                if a:
                    assert all(
                        np.isclose(a[key], b[key], atol=1e-12, rtol=0) for key in a
                    )
    original = engine.run_ds_mpga_v3_cached(frame, attrs, random_state=41)
    fast = run_method("DS-MPGA", frame, attrs, scorer, 41)[-1]
    for side in ["max", "min"]:
        assert np.isclose(
            original[side + "_discrepancy_score"],
            fast[side + "_cv"],
            atol=1e-12,
            rtol=0,
        )
        assert tuple(original[side + "_itemset"].split(", ")) == tuple(
            json.loads(fast[side + "_rule"])
        )
    assert original["actual_evaluations"] == fast["actual_evaluations"]


def save(rows, path):
    temp = path.with_suffix(".tmp.csv")
    pd.DataFrame(rows).to_csv(temp, index=False)
    temp.replace(path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()
    test()
    out = ROOT / "results/large_space_v1" / ("smoke" if args.smoke else "full")
    out.mkdir(parents=True, exist_ok=True)
    dims = [16, 64] if args.smoke else [16, 64, 256, 1024]
    reps = range(1) if args.smoke else range(10)
    seeds = range(1) if args.smoke else range(3)
    provenance = {
        "code_sha256": sha(Path(__file__)),
        "protocol_sha256": sha(ROOT / "docs/large_space_protocol_v1.md"),
        "engine_sha256": sha(ROOT / "src/algorithms/ds_mpga.py"),
        "dimensions": dims,
        "data_repetitions": list(reps),
        "search_seeds": list(seeds),
        "budgets": BUDGETS,
        "rows": 8192,
        "max_length": 3,
        "min_support": 0.1,
    }
    pp = out / "provenance.json"
    if pp.exists():
        assert json.loads(pp.read_text()) == provenance
    else:
        pp.write_text(json.dumps(provenance, indent=2))
    path = out / "details.csv"
    rows = pd.read_csv(path).to_dict("records") if path.exists() else []
    done = {
        (
            r["landscape"],
            int(r["dimensions"]),
            int(r["data_seed"]),
            int(r["search_seed"]),
        )
        for r in rows
    }
    for landscape in ["conjunction", "parity"]:
        for d in dims:
            for rep in reps:
                if all((landscape, d, rep, s) in done for s in seeds):
                    continue
                frame, attrs, signals, digest = generate(d, rep, landscape)
                scorer = Scorer(frame, attrs)
                subset = [attrs[i] for i in signals] + [
                    a for i, a in enumerate(attrs) if i not in signals
                ][:13]
                exact, minimum, number, etime = oracle(scorer, subset)
                assert number == 4992 and np.isclose(minimum, 0, atol=1e-12)
                if landscape == "conjunction":
                    assert np.isclose(exact, 1, atol=1e-12)
                space = sum(math.comb(d, k) * 2**k for k in range(1, 4))
                for seed in seeds:
                    key = (landscape, d, rep, seed)
                    if key in done:
                        continue
                    methods = list(
                        np.random.default_rng(88000 + rep * 100 + seed + d).permutation(
                            ["DS-MPGA", "Random", "Hill climb"]
                        )
                    )
                    for order, method in enumerate(methods):
                        output = run_method(method, frame, attrs, scorer, seed)
                        for result in output:
                            for side in ["max", "min"]:
                                independent = engine.calculate_subgroup_metrics_v2(
                                    frame, json.loads(result[side + "_rule"])
                                )
                                assert independent is not None and np.isclose(
                                    independent["discrepancy_score"],
                                    result[side + "_cv"],
                                    atol=1e-12,
                                    rtol=0,
                                )
                            certified = d == 16 or landscape == "conjunction"
                            upper = exact if certified else 1.0
                            assert result["max_cv"] <= upper + 1e-12
                            row = {
                                "landscape": landscape,
                                "dimensions": d,
                                "data_seed": rep,
                                "search_seed": seed,
                                "method": method,
                                "execution_order": order,
                                "data_sha256": digest,
                                "rule_space": space,
                                "subset_max": exact,
                                "global_max_certified": certified,
                                "global_max_upper": upper,
                                "subset_enumeration_seconds": etime,
                                "mask_setup_seconds": scorer.setup_seconds,
                                "signal_columns": json.dumps(signals),
                                **result,
                            }
                            row["request_space_ratio"] = result["budget"] / space
                            row["reference_gap"] = exact - result["max_cv"]
                            row["max_regret_lower"] = max(0.0, row["reference_gap"])
                            row["max_regret_upper"] = max(0.0, upper - result["max_cv"])
                            row["min_regret"] = result["min_cv"]
                            rows.append(row)
                    done.add(key)
                    save(rows, path)
                print(
                    f"{landscape} d={d} data={rep}: {len(rows)} budget records",
                    flush=True,
                )
    expected = 2 * len(dims) * len(reps) * len(seeds) * 3 * 3
    assert len(rows) == expected
    df = pd.DataFrame(rows)
    assert not df.duplicated(
        ["landscape", "dimensions", "data_seed", "search_seed", "method", "budget"]
    ).any()
    assert (df.actual_evaluations + df.cache_hits == df.budget).all()
    (out / "validation.json").write_text(
        json.dumps(
            {
                "status": "passed",
                "budget_records": len(rows),
                "method_trajectories": len(rows) // 3,
                "independent_data_tables": 2 * len(dims) * len(reps),
                "validation": "Original-vs-fast scorer and canonical search parity; every returned rule independently recomputed; request/cache identities and oracle bounds checked.",
                "provenance": provenance,
            },
            indent=2,
        )
    )
    print("LARGE SPACE COMPLETE", flush=True)


if __name__ == "__main__":
    main()
