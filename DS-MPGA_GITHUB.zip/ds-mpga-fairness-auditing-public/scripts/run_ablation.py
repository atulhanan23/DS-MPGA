"""Checkpointed corrected ablation with strict validation and isolated smoke runs."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import argparse
import hashlib
import itertools
import json
import platform
import random
import numpy as np
import pandas as pd
from src.algorithms import ds_mpga as engine

CONFIGS = {
    "Full DS-MPGA v3 Cached": {},
    "No caching": {"use_cache": False},
    "No migration": {"enable_migration": False},
    "Single population": {
        "n_populations": 1,
        "population_size": 90,
        "enable_migration": False,
    },
    "Max-only search": {"dual_search": False},
}
DATA = ROOT / "prepared_data/ablation_corrected_v1"
KEYS = ["dataset", "configuration", "seed"]


def validate_row(row):
    max_only = row["configuration"] == "Max-only search"
    assert row["total_evaluation_requests"] == (2700 if max_only else 5400)
    assert (
        row["actual_evaluations"] + row["cache_hits"]
        == row["total_evaluation_requests"]
    )
    assert np.isclose(
        row["cache_hit_rate"], row["cache_hits"] / row["total_evaluation_requests"]
    )
    for side in ["max"] + ([] if max_only else ["min"]):
        for metric in [
            "support",
            "metric_subgroup",
            "metric_outside",
            "discrepancy_score",
        ]:
            assert (
                np.isfinite(row[f"{side}_{metric}"])
                and 0 <= row[f"{side}_{metric}"] <= 1
            )
        assert row[f"{side}_support"] >= 0.10
        assert np.isclose(
            row[f"{side}_discrepancy_score"],
            abs(row[f"{side}_metric_subgroup"] - row[f"{side}_metric_outside"]),
        )
    if max_only:
        assert all(
            pd.isna(row[k])
            for k in [
                "min_discrepancy_score",
                "min_support",
                "min_metric_subgroup",
                "min_metric_outside",
                "discrepancy_gap",
            ]
        )
    else:
        assert row["max_discrepancy_score"] >= row["min_discrepancy_score"]
        assert np.isclose(
            row["discrepancy_gap"],
            row["max_discrepancy_score"] - row["min_discrepancy_score"],
        )
    if row["configuration"] == "No caching":
        assert row["cache_hits"] == row["cache_hit_rate"] == 0
        assert row["actual_evaluations"] == row["total_evaluation_requests"]
    assert np.isfinite(row["runtime_seconds"]) and row["runtime_seconds"] >= 0


def atomic_csv(df, path):
    temp = path.with_suffix(".tmp")
    df.to_csv(temp, index=False)
    temp.replace(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    seeds = [0] if args.smoke else list(range(30))
    out = (
        ROOT
        / "results/ablation_corrected_v1"
        / ("smoke_seed0" if args.smoke else "full_30seeds")
    )
    out.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((DATA / "manifest.json").read_text())
    provenance = {
        "data_manifest_sha256": hashlib.sha256(
            (DATA / "manifest.json").read_bytes()
        ).hexdigest(),
        "engine_sha256": hashlib.sha256(
            (ROOT / "src/algorithms/ds_mpga.py").read_bytes()
        ).hexdigest(),
        "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "seeds": seeds,
        "configs": CONFIGS,
        "python": platform.python_version(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "platform": platform.platform(),
        "timing": "Search only; excludes model training, disk writes, and post-run validation.",
    }
    provenance_path = out / "provenance.json"
    if provenance_path.exists():
        assert (
            json.loads(provenance_path.read_text()) == provenance
        ), "Provenance changed; use a new version"
    else:
        provenance_path.write_text(json.dumps(provenance, indent=2))
    checkpoint = out / "ablation_ds_mpga_v3_cached_30seeds_checkpoint.csv"
    rows = pd.read_csv(checkpoint).to_dict("records") if checkpoint.exists() else []
    expected = set(itertools.product(manifest["datasets"], CONFIGS, seeds))
    done = set()
    for row in rows:
        key = tuple(row[k] for k in KEYS)
        assert key in expected and key not in done
        validate_row(row)
        done.add(key)
    for dataset, item in manifest["datasets"].items():
        path = DATA / item["file"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item["sha256"]
        df = pd.read_csv(path)
        for seed in seeds:
            for configuration, settings in CONFIGS.items():
                key = (dataset, configuration, seed)
                if key in done:
                    continue
                result = engine.run_ds_mpga_v3_ablation(
                    df, item["attributes"], random_state=seed, **settings
                )
                state = random.getstate()
                row = dict(
                    dataset=dataset, configuration=configuration, seed=seed, **result
                )
                validate_row(row)
                # Recompute reported rules directly from the source prediction table.
                for side in ["max"] + (
                    [] if configuration == "Max-only search" else ["min"]
                ):
                    rule = row[f"{side}_itemset"].split(", ")
                    assert 1 <= len(rule) <= 3
                    assert len(
                        {engine.get_attribute_from_item(x) for x in rule}
                    ) == len(rule)
                    metrics = engine.calculate_subgroup_metrics_v2(df, rule)
                    assert metrics is not None
                    for metric, value in metrics.items():
                        assert np.isclose(value, row[f"{side}_{metric}"])
                if args.smoke and configuration == "Full DS-MPGA v3 Cached":
                    reference = engine.run_ds_mpga_v3_cached(
                        df, item["attributes"], random_state=seed
                    )
                    assert random.getstate() == state
                    for metric, value in reference.items():
                        if not metric.startswith("runtime_"):
                            assert value == result[metric], metric
                if configuration == "No caching":
                    full = next(
                        r
                        for r in rows
                        if (r["dataset"], r["configuration"], r["seed"])
                        == (dataset, "Full DS-MPGA v3 Cached", seed)
                    )
                    for metric in [
                        k
                        for k in result
                        if k.startswith(("max_", "min_")) or k == "discrepancy_gap"
                    ]:
                        if isinstance(result[metric], str):
                            assert result[metric] == full[metric]
                        else:
                            assert np.isclose(
                                result[metric], full[metric], atol=1e-12, rtol=0
                            )
                rows.append(row)
                done.add(key)
                atomic_csv(pd.DataFrame(rows), checkpoint)
                print(
                    f'{len(done)}/{len(expected)} | {dataset} | {configuration} | seed {seed} | {result["runtime_seconds"]:.2f}s',
                    flush=True,
                )
    assert done == expected
    details = pd.DataFrame(rows)
    assert not details.duplicated(KEYS).any()
    atomic_csv(details, out / "ablation_ds_mpga_v3_cached_30seeds_final.csv")
    summary = (
        details.groupby(KEYS[:2])
        .agg(
            completed_seeds=("seed", "nunique"),
            max_cv_mean=("max_discrepancy_score", "mean"),
            max_cv_std=("max_discrepancy_score", "std"),
            min_cv_mean=("min_discrepancy_score", "mean"),
            min_cv_std=("min_discrepancy_score", "std"),
            gap_mean=("discrepancy_gap", "mean"),
            gap_std=("discrepancy_gap", "std"),
            runtime_mean_seconds=("runtime_seconds", "mean"),
            runtime_std_seconds=("runtime_seconds", "std"),
            actual_evaluations_mean=("actual_evaluations", "mean"),
            cache_hit_rate_mean=("cache_hit_rate", "mean"),
        )
        .reset_index()
    )
    atomic_csv(summary, out / "ablation_ds_mpga_v3_cached_30seeds_summary.csv")
    (out / "validation.json").write_text(
        json.dumps(
            {
                "status": "passed",
                "jobs": len(rows),
                "seeds_per_combination": len(seeds),
                "sample_sd_ddof": 1,
                "smoke_only": args.smoke,
                "rule_metrics_recomputed": True,
                "full_no_cache_matched": True,
            },
            indent=2,
        )
    )
    print("VALIDATED", out, flush=True)


if __name__ == "__main__":
    main()
