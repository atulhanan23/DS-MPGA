"""Descriptive summaries; average random repetitions within table first."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import json
import pandas as pd


def main():
    out = ROOT / "results/journal_extension_v1/full"
    validation = json.loads((out / "validation.json").read_text())
    assert validation["status"] == "passed"
    opt = pd.read_csv(out / "optimality.csv")
    random = pd.read_csv(out / "random_baseline.csv")
    confirm = pd.read_csv(out / "confirmation.csv")
    keys = ["dataset", "classifier", "seed"]
    groups = keys[:2]
    assert not opt.duplicated(keys).any()
    assert len(opt) == 1200 and len(random) == 24000
    assert random.groupby(keys).size().eq(20).all()
    random_mean = (
        random.groupby(keys)[
            ["max_score", "min_score", "max_ds_advantage", "min_ds_advantage"]
        ]
        .mean()
        .reset_index()
    )
    combined = opt.merge(random_mean, on=keys, validate="one_to_one")
    combined.to_csv(out / "comparison_per_table.csv", index=False)
    summary = (
        combined.groupby(groups)
        .agg(
            n=("seed", "size"),
            rule_space_min=("rule_space", "min"),
            rule_space_max=("rule_space", "max"),
            valid_rules_mean=("valid_rules", "mean"),
            ds_work_mean=("ds_actual_evaluations", "mean"),
            max_exact_hit_rate=("max_exact_hit", "mean"),
            min_exact_hit_rate=("min_exact_hit", "mean"),
            max_regret_mean=("max_regret", "mean"),
            max_regret_worst=("max_regret", "max"),
            min_regret_mean=("min_regret", "mean"),
            ds_max_mean=("max_ds", "mean"),
            exact_max_mean=("max_exact", "mean"),
            random_max_mean=("max_score", "mean"),
            ds_minus_random_max=("max_ds_advantage", "mean"),
            random_minus_ds_min=("min_ds_advantage", "mean"),
        )
        .reset_index()
    )
    summary.to_csv(out / "optimality_summary.csv", index=False)
    assert len(confirm) == 360 * 44
    confirm["confirmation_undefined"] = ~confirm.confirmation_defined.fillna(
        False
    ).astype(bool)
    confirm["confirmation_support_violation"] = ~confirm.confirmation_support_ok.fillna(
        False
    ).astype(bool)
    metrics = [
        "discovery_cv",
        "confirmation_cv",
        "cv_change",
        "confirmation_support",
        "confirmation_undefined",
        "confirmation_support_violation",
        "direction_agrees",
    ]
    per_table = (
        confirm.groupby(keys + ["method", "direction"])[metrics].mean().reset_index()
    )
    per_table.to_csv(out / "confirmation_per_table.csv", index=False)
    cs = (
        per_table.groupby(groups + ["method", "direction"])
        .agg(
            n=("seed", "size"),
            discovery_cv_mean=("discovery_cv", "mean"),
            confirmation_cv_mean=("confirmation_cv", "mean"),
            change_mean=("cv_change", "mean"),
            change_median=("cv_change", "median"),
            change_q10=("cv_change", lambda s: s.quantile(0.1)),
            change_q90=("cv_change", lambda s: s.quantile(0.9)),
            confirmation_support_mean=("confirmation_support", "mean"),
            undefined_rate=("confirmation_undefined", "mean"),
            support_violation_rate=("confirmation_support_violation", "mean"),
            direction_agreement_rate=("direction_agrees", "mean"),
        )
        .reset_index()
    )
    cs.to_csv(out / "confirmation_summary.csv", index=False)
    overview = {
        "tables": len(opt),
        "max_exact_hits": int(opt.max_exact_hit.sum()),
        "min_exact_hits": int(opt.min_exact_hit.sum()),
        "max_regret_mean": float(opt.max_regret.mean()),
        "max_regret_worst": float(opt.max_regret.max()),
        "random_no_valid_selections": int((~random.max_defined).sum()),
        "all_rule_spaces_below_request_budget": bool(opt.rule_space.le(5400).all()),
        "max_positive_mean_advantage_groups": int(
            summary.ds_minus_random_max.gt(0).sum()
        ),
        "ds_max_confirmation": per_table.query(
            'method == "DS-MPGA" and direction == "max"'
        )[metrics]
        .mean()
        .to_dict(),
        "note": "All estimates are descriptive benchmark/resampling summaries, not independent-population confidence statements.",
    }
    (out / "overview.json").write_text(json.dumps(overview, indent=2))
    print(json.dumps(overview, indent=2))
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
