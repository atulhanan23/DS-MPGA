"""Restyle frozen figure data; retain all values and uncertainty definitions."""
from pathlib import Path
import sys,json,hashlib,re,subprocess
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=ROOT/'outputs/retained_plots';F=P/'figures';S=ROOT/'results/validated';F.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'Times New Roman','font.size':11,'axes.labelsize':11,'axes.titlesize':12,'legend.fontsize':10.5,'xtick.labelsize':10.5,'ytick.labelsize':10.5,'axes.linewidth':.8,'lines.linewidth':1.6,'svg.fonttype':'none','pdf.fonttype':42,'savefig.dpi':400})
COLORS=['#234f82','#b65d18','#397c60','#865096'];MODELS=['Logistic Regression','Decision Tree','Random Forest','XGBoost'];LABELS=['LR','DT','RF','XGBoost'];DS=['Adult Income','COMPAS','German Credit']
inventory=[]
def save(fig,number,name,source):
    stem=f'Figure_{number:02d}_{name}'
    for ext in ['svg','pdf','png']:fig.savefig(F/(stem+'.'+ext),bbox_inches='tight',pad_inches=.045)
    inventory.append({'figure':number,'file':stem,'source':source,'minimum_font_points':10.5,'placement':'Full printable width / span both journal columns','data_changed':False})
    plt.close(fig)

a=pd.read_csv(S/'ablation/corrected_450_jobs.csv')
fig,ax=plt.subplots(figsize=(6.45,3.1));x=np.arange(3);width=.33
for shift,config,label,color in [(-width/2,'Full DS-MPGA v3 Cached','Full (cached)',COLORS[0]),(width/2,'No caching','No caching',COLORS[1])]:
    g=a[a.configuration.eq(config)].groupby('dataset').runtime_seconds.agg(['mean','std']).reindex(DS)
    ax.bar(x+shift,g['mean'],width,yerr=g['std'],capsize=4,color=color,label=label,error_kw={'elinewidth':1.1})
ax.set_yscale('log');ax.set_xticks(x,DS);ax.set_ylabel('Search time (seconds; log scale)');ax.legend(frameon=False);ax.spines[['top','right']].set_visible(False);fig.tight_layout()
save(fig,3,'cache_runtime','supplementary/ablation/corrected_450_jobs.csv; mean ± sample SD, 30 seeds')

s=pd.read_csv(S/'sensitivity/all_classifier_summaries.csv')
fig,axs=plt.subplots(3,2,figsize=(6.45,5.9),sharey=True)
for row,ds in enumerate(DS):
    for col,(settings,xs,xlabel) in enumerate([(['support_005','reference','support_020'],[.05,.1,.2],'Minimum support'),(['length_1','length_2','reference'],[1,2,3],'Maximum rule length')]):
        ax=axs[row,col]
        for model,label,color in zip(MODELS,LABELS,COLORS):
            sub=s[s.dataset.eq(ds)&s.classifier.eq(model)].set_index('setting').loc[settings]
            ax.plot(xs,sub.max_discrepancy_score_mean,'o-',color=color,label=label,markersize=4)
        ax.set_ylim(0,.8);ax.set_yticks([0,.4,.8]);ax.set_xticks(xs);ax.set_title(ds,pad=4);ax.set_xlabel(xlabel,labelpad=2);ax.spines[['top','right']].set_visible(False)
        if col==0:ax.set_ylabel('Mean Max CV')
handles,labels=axs[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',ncol=4,frameon=False,bbox_to_anchor=(.52,1.015));fig.tight_layout(rect=(0,0,1,.97),h_pad=.9,w_pad=1)
save(fig,4,'sensitivity','supplementary/sensitivity/all_classifier_summaries.csv; unchanged means')

opt=pd.read_csv(S/'search_references/exact_per_run_1200.csv');conf=pd.read_csv(S/'confirmation/locked_rule_records.csv')
fig,axs=plt.subplots(1,2,figsize=(6.45,3.2),gridspec_kw={'width_ratios':[1.05,1]})
ax=axs[0];arr=[];labs=[]
for ds in DS:
    for side in ['max','min']:
        arr.append([100*opt[opt.dataset.eq(ds)&opt.classifier.eq(m)][side+'_exact_hit'].mean() for m in MODELS]);labs.append(ds.replace(' Income','').replace(' Credit','')+' '+side.title())
arr=np.array(arr);ax.imshow(arr,cmap='Blues',vmin=0,vmax=100,aspect='auto');ax.set_xticks(range(4),LABELS,rotation=25,ha='right');ax.set_yticks(range(6),labs);ax.tick_params(length=0);ax.set_title('Exact attainment (%)',pad=9)
for i in range(6):
    for j in range(4):ax.text(j,i,f'{arr[i,j]:.0f}',ha='center',va='center',color='white' if arr[i,j]>65 else '#213544',fontsize=11)
ax=axs[1];z=conf[conf.method.eq('DS-MPGA')&conf.direction.eq('max')]
for key,label,col in [('discovery_cv','Discovery',COLORS[0]),('confirmation_cv','Confirmation',COLORS[1])]:ax.plot(range(3),z.groupby('dataset')[key].mean().reindex(DS),'o-',label=label,color=col,markersize=4)
ax.set_xticks(range(3),['Adult','COMPAS','German']);ax.set_ylim(0,.6);ax.set_yticks([0,.3,.6]);ax.set_title('Discovery and confirmation',fontsize=11.5,pad=9);ax.set_ylabel('Mean Max CV');ax.spines[['top','right']].set_visible(False);ax.legend(loc='lower center',frameon=False,fontsize=10.5);fig.tight_layout(w_pad=1.0)
save(fig,5,'exact_confirmation','supplementary/search_references/exact_per_run_1200.csv; supplementary/confirmation/locked_rule_records.csv')

z=pd.read_csv(S/'scalability/summary.csv');fig,axs=plt.subplots(2,2,figsize=(6.45,4.4),sharey=True)
for ax,dim in zip(axs.flat,[16,64,256,1024]):
    for method,label,col in zip(['DS-MPGA','Random','Hill climb'],['DS-MPGA','Random search','Hill climbing'],COLORS):
        sub=z[z.landscape.eq('conjunction')&z.dimensions.eq(dim)&z.method.eq(method)].sort_values('budget');ax.plot(sub.budget,sub.max_cv_mean,'o-',color=col,label=label,markersize=4)
    ax.axhline(1,color='#6d7780',linestyle='--',linewidth=1);ax.set_title(f'{dim:,} attributes',pad=4);ax.set_ylim(0,1.07);ax.set_yticks([0,.5,1]);ax.set_xticks([540,1800,5400],['540','1,800','5,400']);ax.set_xlabel('Evaluation requests',labelpad=2);ax.spines[['top','right']].set_visible(False)
for ax in axs[:,0]:ax.set_ylabel('Mean Max CV')
handles,labels=axs[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',ncol=3,frameon=False,bbox_to_anchor=(.53,1.03));fig.tight_layout(rect=(0,0,1,.97),h_pad=.9)
save(fig,6,'conjunction_scaling','supplementary/scalability/summary.csv; unchanged table-weighted means and certified reference')
(P/'figure_provenance.json').write_text(json.dumps(inventory,indent=2),encoding='utf-8')
print('Regenerated retained plots from frozen aggregate evidence; no training/search rerun.')
