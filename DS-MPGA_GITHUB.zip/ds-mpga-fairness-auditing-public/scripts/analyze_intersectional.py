"""Versioned classification, independent recomputation and restricted exact audit."""

import sys, json, hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.preprocessing.paths import prediction_path
import numpy as np
import pandas as pd
from scripts.run_journal_extension import enumerate_rules, evaluate_fixed
from scripts.run_xgboost import DATASETS
from scripts.build_final_evidence import conditional_metrics
from scripts.run_ablation import validate_row

OUT = ROOT / "results/intersectional_v1"
P = {
    "Adult Income": {"sex", "race", "age_group"},
    "COMPAS": {"sex", "race", "age_cat"},
    "German Credit": {"sex_group", "age_group"},
}


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def classify(dataset, rule):
    attrs = {x.split(" = ", 1)[0] for x in rule}
    prot = attrs & P[dataset]
    context = attrs - prot
    category = (
        "contextual"
        if not prot
        else (
            "mixed"
            if context
            else ("protected intersection" if len(prot) >= 2 else "single protected")
        )
    )
    return dict(
        category=category,
        protected_attributes="; ".join(sorted(prot)),
        contextual_attributes="; ".join(sorted(context)),
        protected_count=len(prot),
        is_intersectional=len(prot) >= 2,
        is_intersectional_without_age=len(prot - {"age_group", "age_cat"}) >= 2,
    )


def summarize(df, keys):
    return (
        df.groupby(keys, dropna=False)
        .agg(
            n=("rule", "size"),
            cv_mean=("cv", "mean"),
            cv_sd=("cv", "std"),
            cv_median=("cv", "median"),
            cv_max=("cv", "max"),
            support_mean=("support", "mean"),
            support_min=("support", "min"),
            support_median=("support", "median"),
            support_max=("support", "max"),
            intersectional_count=("is_intersectional", "sum"),
            distinct_rules=("rule_key", "nunique"),
        )
        .reset_index()
    )


def main():
    OUT.mkdir(exist_ok=True)
    src = ROOT / "results/final_evidence_v1/verified_subgroups_all.csv"
    base = pd.read_csv(src)
    details = pd.read_csv(
        ROOT / "results/final_evidence_v1/four_classifier_100seeds_all_details.csv"
    )
    opt = pd.read_csv(
        ROOT / "results/journal_extension_v1/full/optimality.csv"
    ).set_index(["dataset", "classifier", "seed"])
    confirm = pd.read_csv(ROOT / "results/journal_extension_v1/full/confirmation.csv")
    confirm = confirm[confirm.method.eq("DS-MPGA")]
    provenance = {
        "analysis_code_sha256": sha(Path(__file__)),
        "protocol_sha256": sha(ROOT / "docs/intersectional_protocol.md"),
        "sources": {
            str(p.relative_to(ROOT)): sha(p)
            for p in [
                src,
                ROOT / "results/journal_extension_v1/full/confirmation.csv",
                ROOT / "results/journal_extension_v1/full/optimality.csv",
            ]
        },
    }
    rows = []
    cr = []
    restricted = []
    levels = {}
    for ix, (key, g) in enumerate(base.groupby(["dataset", "classifier", "seed"])):
        dataset, clf, seed = key
        path = prediction_path(ROOT, g.iloc[0].prediction_file)
        assert sha(path) == g.iloc[0].prediction_sha256
        table = pd.read_csv(path)
        attrs = DATASETS[dataset][2]
        if dataset not in levels:
            levels[dataset] = {
                a: sorted(table[a].astype(str).unique().tolist()) for a in attrs
            }
        for r in g.to_dict("records"):
            rule = json.loads(r["rule_key"])
            m = evaluate_fixed(table, rule)
            assert np.isclose(m["cv"], r["discrepancy_score"], atol=1e-12, rtol=0)
            assert np.isclose(m["support"], r["support"], atol=1e-12, rtol=0)
            mask = np.ones(len(table), bool)
            for item in rule:
                a, v = item.split(" = ", 1)
                mask &= table[a].astype(str).to_numpy() == v
            cond = conditional_metrics(
                table.true_label.to_numpy(), table.prediction.to_numpy(), mask
            )
            for c in ["tpr_gap", "fpr_gap", "ppv_gap", "equalized_odds_gap"]:
                assert np.isclose(cond[c], r[c], atol=1e-12, rtol=0, equal_nan=True)
            o = opt.loc[key]
            side = r["direction"]
            rows.append(
                r
                | m
                | classify(dataset, rule)
                | {
                    "exact_regret": o[side + "_regret"],
                    "exact_hit": o[side + "_exact_hit"],
                    "cv_gap": o.max_ds - o.min_ds,
                    "confirmation_cv": np.nan,
                    "confirmation_note": "Not measured for this full-test selected rule; separate discovery-half rules below.",
                }
            )
        rules, scores, supports = enumerate_rules(table, attrs)
        indices = [
            i
            for i, r in enumerate(rules)
            if np.isfinite(scores[i]) and classify(dataset, r)["is_intersectional"]
        ]
        assert indices
        for side in ["max", "min"]:
            i = indices[
                int(
                    np.argmax(scores[indices])
                    if side == "max"
                    else np.argmin(scores[indices])
                )
            ]
            rule = rules[i]
            m = evaluate_fixed(table, rule)
            assert np.isclose(m["cv"], scores[i], atol=1e-12, rtol=0)
            restricted.append(
                dict(
                    dataset=dataset,
                    classifier=clf,
                    seed=seed,
                    direction=side,
                    rule=", ".join(rule),
                    rule_key=json.dumps(rule),
                    rule_length=len(rule),
                    valid_constrained_rules=len(indices),
                    **m,
                    **classify(dataset, rule),
                    unconstrained_exact=opt.loc[key][side + "_exact"],
                    unconstrained_ds=opt.loc[key][side + "_ds"],
                )
            )
        if seed < 30:
            perm = np.random.default_rng(100000 + seed).permutation(len(table))
            disc = table.iloc[perm[: len(table) // 2]]
            conf = table.iloc[perm[len(table) // 2 :]]
            for r in confirm[
                (confirm.dataset == dataset)
                & (confirm.classifier == clf)
                & (confirm.seed == seed)
            ].to_dict("records"):
                rule = json.loads(r["rule"])
                dm = evaluate_fixed(disc, rule)
                cm = evaluate_fixed(conf, rule)
                for name, m in [("discovery", dm), ("confirmation", cm)]:
                    for a, b in [
                        ("cv", "cv"),
                        ("support", "support"),
                        ("inside_n", "inside_n"),
                        ("outside_n", "outside_n"),
                        ("signed_difference", "signed_difference"),
                    ]:
                        assert np.isclose(
                            r[name + "_" + a], m[b], atol=1e-12, rtol=0, equal_nan=True
                        )
                cr.append(
                    r
                    | classify(dataset, rule)
                    | {
                        "rule_key": json.dumps(sorted(rule)),
                        "rule": ", ".join(rule),
                        "rule_length": len(rule),
                        "cv": dm["cv"],
                        "support": dm["support"],
                    }
                )
        if ix % 100 == 0:
            print(f"Verified {ix+1}/1200 prediction tables", flush=True)
    df = pd.DataFrame(rows)
    cf = pd.DataFrame(cr)
    ex = pd.DataFrame(restricted)
    assert len(df) == 2400 and len(cf) == 720 and len(ex) == 2400
    df.to_csv(OUT / "classified_primary_rules.csv", index=False)
    cf.to_csv(OUT / "classified_confirmation_rules.csv", index=False)
    ex.to_csv(OUT / "restricted_exact_rules.csv", index=False)
    summarize(df, ["dataset", "classifier", "direction", "category"]).to_csv(
        OUT / "category_by_classifier.csv", index=False
    )
    summarize(df, ["dataset", "direction", "category"]).to_csv(
        OUT / "category_by_dataset.csv", index=False
    )
    summarize(df[df.is_intersectional], ["dataset", "classifier", "direction"]).to_csv(
        OUT / "intersectional_by_classifier.csv", index=False
    )
    summarize(ex, ["dataset", "classifier", "direction"]).to_csv(
        OUT / "restricted_summary.csv", index=False
    )
    df.groupby(["dataset", "classifier", "direction", "rule_key"]).agg(
        recurrence=("seed", "size"),
        rule=("rule", "first"),
        category=("category", "first"),
        is_intersectional=("is_intersectional", "first"),
        cv_mean=("cv", "mean"),
        support_mean=("support", "mean"),
    ).reset_index().to_csv(OUT / "rule_recurrence.csv", index=False)
    df.groupby(["dataset", "direction", "rule_key"]).agg(
        classifiers=("classifier", "nunique"),
        runs=("seed", "size"),
        rule=("rule", "first"),
        is_intersectional=("is_intersectional", "first"),
    ).reset_index().to_csv(OUT / "cross_classifier_recurrence.csv", index=False)
    df.groupby(
        ["dataset", "classifier", "direction", "category", "rule_length"]
    ).size().reset_index(name="n").to_csv(OUT / "rule_lengths.csv", index=False)
    cf.groupby(["dataset", "direction", "category"]).agg(
        n=("rule", "size"),
        discovery_cv=("discovery_cv", "mean"),
        confirmation_cv=("confirmation_cv", "mean"),
        change=("cv_change", "mean"),
        direction_agrees=("direction_agrees", "mean"),
        support_ok=("confirmation_support_ok", "mean"),
    ).reset_index().to_csv(OUT / "confirmation_categories.csv", index=False)
    df[df.seed.eq(0)].to_csv(OUT / "representative_seed0_rules.csv", index=False)
    df[df.is_intersectional].sort_values(
        ["cv", "seed"], ascending=[False, True]
    ).groupby(["dataset", "classifier", "direction"]).head(1).to_csv(
        OUT / "intersectional_examples.csv", index=False
    )
    # Re-audit the separate fixed-table ablation without changing its outputs.
    ab = pd.read_csv(
        ROOT
        / "results/ablation_corrected_v1/full_30seeds/ablation_ds_mpga_v3_cached_30seeds_final.csv"
    )
    assert (
        len(ab) == 450 and not ab.duplicated(["dataset", "configuration", "seed"]).any()
    )
    for _, g in ab.groupby(["dataset", "configuration"]):
        assert set(g.seed) == set(range(30))
    for r in ab.to_dict("records"):
        validate_row(r)
    ab.groupby(["dataset", "configuration"])[
        [
            "max_discrepancy_score",
            "min_discrepancy_score",
            "runtime_seconds",
            "cache_hit_rate",
        ]
    ].agg(["mean", "std"]).to_csv(OUT / "ablation_recomputed_summary.csv")
    (OUT / "attribute_levels.json").write_text(json.dumps(levels, indent=2))
    (OUT / "provenance.json").write_text(json.dumps(provenance, indent=2))
    overview = {
        "primary_rules": 2400,
        "confirmation_rules": 720,
        "restricted_exact_witnesses": 2400,
        "intersectional_primary": int(df.is_intersectional.sum()),
        "intersectional_without_age": int(df.is_intersectional_without_age.sum()),
        "categories": df.category.value_counts().to_dict(),
        "source_note": "Full-test selections and discovery-half selections remain separate.",
    }
    (OUT / "overview.json").write_text(json.dumps(overview, indent=2))
    print(json.dumps(overview, indent=2))
    (OUT / "validation.json").write_text(
        json.dumps(
            {
                "status": "passed",
                "primary_prediction_tables_verified": 1200,
                "primary_rules_recomputed": 2400,
                "confirmation_rules_recomputed": 720,
                "restricted_witnesses_recomputed": 2400,
                "ablation_rows_validated": 450,
                "source_hashes_preserved": all(
                    sha(ROOT / p) == v for p, v in provenance["sources"].items()
                ),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
