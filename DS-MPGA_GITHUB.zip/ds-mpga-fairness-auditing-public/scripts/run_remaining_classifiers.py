"""Reconstruct LR/DT/RF locally with saved predictions; preserve historical runs."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.preprocessing.paths import prediction_path
import argparse
import hashlib
import json
import platform
import time
import warnings
import numpy as np
import pandas as pd
import sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score
from sklearn.exceptions import ConvergenceWarning
from scripts.run_xgboost import DATASETS, prepare, source, sha, verify_prediction_table
from scripts.run_ablation import atomic_csv, validate_row
from src.algorithms.ds_mpga import run_ds_mpga_v3_cached

MODELS = {
    "Logistic Regression": (
        "lr",
        LogisticRegression,
        {"max_iter": 1000, "class_weight": "balanced"},
    ),
    "Decision Tree": (
        "dt",
        DecisionTreeClassifier,
        {"random_state": 42, "class_weight": "balanced"},
    ),
    "Random Forest": (
        "rf",
        RandomForestClassifier,
        {
            "n_estimators": 100,
            "random_state": 42,
            "class_weight": "balanced",
            "n_jobs": -1,
        },
    ),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()
    seeds = [0] if args.smoke else list(range(100))
    mode = "smoke_seed0" if args.smoke else "full_100seeds"
    out = ROOT / "results/classifiers_reconstructed_v1" / mode
    data = ROOT / "prepared_data/classifiers_reconstructed_v1" / mode
    out.mkdir(parents=True, exist_ok=True)
    data.mkdir(parents=True, exist_ok=True)
    provenance = {
        "reason": "Complete prediction provenance for all four classifiers, original results preserved",
        "models": {name: spec[2] for name, spec in MODELS.items()},
        "seeds": seeds,
        "split": "stratified 70/30; split seed equals search seed",
        "preprocessing": "safe notebook builder; full-data dummy vocabulary; StandardScaler fit to training rows only for LR; numeric float64 equivalent to original encoded values",
        "python": platform.python_version(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "sklearn": sklearn.__version__,
        "sources": {name: sha(source(spec[1])) for name, spec in DATASETS.items()},
        "code": {
            name: sha(
                ROOT
                / (
                    "src/algorithms/ds_mpga.py"
                    if name == "ablation_engine.py"
                    else "scripts/" + name
                )
            )
            for name in [
                "run_remaining_classifiers.py",
                "run_xgboost.py",
                "ablation_engine.py",
            ]
        },
    }
    pp = out / "provenance.json"
    if pp.exists():
        assert json.loads(pp.read_text()) == provenance
    else:
        pp.write_text(json.dumps(provenance, indent=2))
    checkpoint = out / "classifier_details_checkpoint.csv"
    rows = pd.read_csv(checkpoint).to_dict("records") if checkpoint.exists() else []
    expected = {(d, c, s) for d in DATASETS for c in MODELS for s in seeds}
    done = set()
    for row in rows:
        key = (row["dataset"], row["classifier"], row["seed"])
        assert key in expected and key not in done
        validate_row(dict(row, configuration="Full DS-MPGA v3 Cached"))
        assert sha(prediction_path(ROOT, row["prediction_file"])) == row["prediction_sha256"]
        done.add(key)
    for dataset, (slug, _, attrs) in DATASETS.items():
        df, y, x, _, _ = prepare(dataset)
        x = x.astype(np.float64)
        for classifier, (short, ctor, params) in MODELS.items():
            for seed in seeds:
                if (dataset, classifier, seed) in done:
                    continue
                train, test = train_test_split(
                    np.arange(len(df)), test_size=0.30, random_state=seed, stratify=y
                )
                assert not set(train) & set(test)
                xtrain, xtest = x.iloc[train], x.iloc[test]
                start = time.perf_counter()
                if classifier == "Logistic Regression":
                    scaler = StandardScaler()
                    xtrain = scaler.fit_transform(xtrain)
                    xtest = scaler.transform(xtest)
                model = ctor(**params)
                with warnings.catch_warnings(record=True) as caught:
                    warnings.simplefilter("always")
                    model.fit(xtrain, y.iloc[train])
                    pred = model.predict(xtest)
                assert not any(
                    issubclass(w.category, ConvergenceWarning) for w in caught
                ), "LR failed to converge"
                training = time.perf_counter() - start
                table = df.loc[test, attrs].reset_index(drop=True)
                table["prediction"] = pred
                table["true_label"] = y.iloc[test].to_numpy()
                table["source_row_index"] = test
                result = run_ds_mpga_v3_cached(table, attrs, random_state=seed)
                row = dict(
                    dataset=dataset,
                    classifier=classifier,
                    seed=seed,
                    accuracy=accuracy_score(y.iloc[test], pred),
                    f1_score=f1_score(y.iloc[test], pred),
                    training_seconds=training,
                    **result,
                )
                validate_row(dict(row, configuration="Full DS-MPGA v3 Cached"))
                verify_prediction_table(table, row, attrs)
                dest = data / f"{slug}_{short}_seed{seed:03d}_predictions.csv.gz"
                table.to_csv(
                    dest, index=False, compression={"method": "gzip", "mtime": 0}
                )
                row.update(
                    prediction_file=str(dest.relative_to(ROOT)),
                    prediction_sha256=sha(dest),
                    train_rows=len(train),
                    test_rows=len(test),
                    train_index_sha256=hashlib.sha256(
                        np.asarray(train, dtype="<i8").tobytes()
                    ).hexdigest(),
                    test_index_sha256=hashlib.sha256(
                        np.asarray(test, dtype="<i8").tobytes()
                    ).hexdigest(),
                    training_warnings=" | ".join(str(w.message) for w in caught),
                )
                rows.append(row)
                done.add((dataset, classifier, seed))
                atomic_csv(pd.DataFrame(rows), checkpoint)
                print(
                    f'{len(done)}/{len(expected)} | {dataset} | {classifier} | {seed} | train {training:.2f}s | search {result["runtime_seconds"]:.2f}s',
                    flush=True,
                )
    assert done == expected
    atomic_csv(pd.DataFrame(rows), out / "classifier_details_final.csv")
    (out / "validation.json").write_text(
        json.dumps(
            {
                "status": "passed",
                "jobs": len(rows),
                "seeds_per_group": len(seeds),
                "prediction_tables_saved": True,
            },
            indent=2,
        )
    )
    print("VALIDATED", out, flush=True)


if __name__ == "__main__":
    main()
