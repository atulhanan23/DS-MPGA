"""Exact finite-space audit, matched-work random baseline, held-out confirmation.

New version only; no tuning or alteration of the frozen DS-MPGA algorithm.
"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.preprocessing.paths import prediction_path
import argparse, hashlib, itertools, json, time
import numpy as np
import pandas as pd
from scripts.run_xgboost import DATASETS, sha
from src.algorithms import ds_mpga as engine


def bitmask(a):
    return int.from_bytes(
        np.packbits(np.asarray(a, dtype=np.uint8), bitorder="little").tobytes(),
        "little",
    )


def enumerate_rules(table, attrs):
    """All syntactic rules, including invalid-support rules, in canonical order."""
    n = len(table)
    full = (1 << n) - 1
    positive = bitmask(table.prediction.to_numpy() == 1)
    total = positive.bit_count()
    levels = []
    masks = {}
    for attr in attrs:
        values = table[attr].astype(str)
        items = [f"{attr} = {v}" for v in sorted(values.unique())]
        levels.append(items)
        for item in items:
            masks[item] = bitmask(values.to_numpy() == item.split(" = ", 1)[1])
    rules = []
    scores = []
    supports = []
    for length in range(1, 4):
        for combo in itertools.combinations(range(len(attrs)), length):
            for items in itertools.product(*(levels[i] for i in combo)):
                mask = full
                for item in items:
                    mask &= masks[item]
                inside = mask.bit_count()
                rules.append(tuple(sorted(items)))
                supports.append(inside / n)
                if inside / n < 0.1 or inside == n or inside == 0:
                    scores.append(np.nan)
                    continue
                hits = (mask & positive).bit_count()
                scores.append(abs(hits / inside - (total - hits) / (n - inside)))
    scores = np.asarray(scores)
    assert np.isfinite(scores).any()
    return rules, scores, np.asarray(supports)


def evaluate_fixed(table, rule):
    mask = np.ones(len(table), bool)
    for item in rule:
        attr, value = item.split(" = ", 1)
        mask &= table[attr].astype(str).to_numpy() == value
    inside = int(mask.sum())
    outside = len(table) - inside
    a = float(table.loc[mask, "prediction"].mean()) if inside else np.nan
    b = float(table.loc[~mask, "prediction"].mean()) if outside else np.nan
    return {
        "support": inside / len(table),
        "inside_n": inside,
        "outside_n": outside,
        "signed_difference": a - b,
        "cv": abs(a - b),
        "defined": bool(inside and outside),
        "support_ok": bool(inside / len(table) >= 0.1),
    }


def chosen(scores, indices, side):
    valid = indices[np.isfinite(scores[indices])]
    if not len(valid):
        return None
    return int(
        valid[np.argmax(scores[valid]) if side == "max" else np.argmin(scores[valid])]
    )


def verify_oracle(table, attrs, all_rules=False):
    rules, scores, _ = enumerate_rules(table, attrs)
    indices = (
        range(len(rules))
        if all_rules
        else np.unique(np.linspace(0, len(rules) - 1, 31, dtype=int))
    )
    for i in indices:
        result = engine.calculate_subgroup_metrics_v2(table, rules[i])
        if result is None:
            assert np.isnan(scores[i])
        else:
            assert np.isclose(
                result["discrepancy_score"], scores[i], atol=1e-12, rtol=0
            )
    return rules, scores


def synthetic_test():
    table = pd.DataFrame(
        {
            "a": ["x", "x", "y", "y"] * 3,
            "b": ["u", "v"] * 6,
            "c": ["q"] * 6 + ["r"] * 6,
            "prediction": [1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1],
        }
    )
    rules, scores = verify_oracle(table, ["a", "b", "c"], True)
    assert len(rules) == 26
    assert len(set(rules)) == len(rules)
    assert chosen(scores, np.flatnonzero(np.isnan(scores)), "max") is None


def atomic(rows, path):
    temp = path.with_suffix(".tmp.csv")
    pd.DataFrame(rows).to_csv(temp, index=False)
    temp.replace(path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()
    synthetic_test()
    out = ROOT / "results/journal_extension_v1" / ("smoke" if args.smoke else "full")
    out.mkdir(parents=True, exist_ok=True)
    source = ROOT / "results/final_evidence_v1/four_classifier_100seeds_all_details.csv"
    details = pd.read_csv(source)
    if args.smoke:
        details = details[details.seed.eq(0)]
    provenance = {
        "source_sha256": sha(source),
        "code_sha256": sha(Path(__file__)),
        "engine_sha256": sha(ROOT / "src/algorithms/ds_mpga.py"),
        "protocol_sha256": sha(ROOT / "docs/journal_extension_protocol_v1.md"),
        "random_repetitions": 20,
        "confirmation_seeds": list(range(30)),
        "confirmation_split": "permutation default_rng(100000 + original seed), first floor(n/2) discovery; rest confirmation",
        "score_tolerance": 1e-12,
    }
    pp = out / "provenance.json"
    if pp.exists():
        assert json.loads(pp.read_text()) == provenance
    else:
        pp.write_text(json.dumps(provenance, indent=2))
    paths = {
        k: out / (k + ".csv")
        for k in ["optimality", "random_baseline", "confirmation", "confirmation_runs"]
    }
    data = {
        k: pd.read_csv(p).to_dict("records") if p.exists() else []
        for k, p in paths.items()
    }
    completed = {
        (r["dataset"], r["classifier"], int(r["seed"])) for r in data["optimality"]
    }
    for name in ["random_baseline", "confirmation", "confirmation_runs"]:
        data[name] = [
            r
            for r in data[name]
            if (r["dataset"], r["classifier"], int(r["seed"])) in completed
        ]
    for number, row in enumerate(details.to_dict("records")):
        key = (row["dataset"], row["classifier"], int(row["seed"]))
        if key in completed:
            continue
        path = prediction_path(ROOT, row["prediction_file"])
        assert sha(path) == row["prediction_sha256"]
        table = pd.read_csv(path)
        attrs = DATASETS[row["dataset"]][2]
        seed = int(row["seed"])
        rules, scores = verify_oracle(table, attrs)
        valid = np.flatnonzero(np.isfinite(scores))
        lookup = {r: i for i, r in enumerate(rules)}
        base = {
            k: row[k]
            for k in [
                "dataset",
                "classifier",
                "seed",
                "prediction_file",
                "prediction_sha256",
            ]
        }
        budget = min(int(row["actual_evaluations"]), len(rules))
        assert budget > 0
        record = base | {
            "rule_space": len(rules),
            "valid_rules": len(valid),
            "ds_actual_evaluations": int(row["actual_evaluations"]),
            "random_budget": budget,
        }
        for side in ["max", "min"]:
            exact_i = chosen(scores, valid, side)
            ds_rule = tuple(sorted(row[side + "_itemset"].split(", ")))
            ds_score = float(row[side + "_discrepancy_score"])
            assert np.isclose(scores[lookup[ds_rule]], ds_score, atol=1e-12, rtol=0)
            regret = (
                (scores[exact_i] - ds_score)
                if side == "max"
                else (ds_score - scores[exact_i])
            )
            assert regret >= -1e-12
            record.update(
                {
                    side + "_exact": scores[exact_i],
                    side + "_ds": ds_score,
                    side + "_regret": max(0.0, regret),
                    side + "_exact_hit": abs(regret) <= 1e-12,
                    side + "_exact_rule": json.dumps(rules[exact_i]),
                }
            )
        for repeat in range(20):
            indices = np.random.default_rng(200000 + seed * 100 + repeat).permutation(
                len(rules)
            )[:budget]
            rb = base | {"repeat": repeat, "budget": budget}
            for side in ["max", "min"]:
                chosen_i = chosen(scores, indices, side)
                value = scores[chosen_i] if chosen_i is not None else np.nan
                rb[side + "_score"] = value
                rb[side + "_defined"] = chosen_i is not None
                rb[side + "_ds_advantage"] = (
                    (record[side + "_ds"] - value)
                    if side == "max"
                    else (value - record[side + "_ds"])
                )
            data["random_baseline"].append(rb)
        if seed < 30:
            permutation = np.random.default_rng(100000 + seed).permutation(len(table))
            middle = len(table) // 2
            discovery = table.iloc[permutation[:middle]].reset_index(drop=True)
            confirmation = table.iloc[permutation[middle:]].reset_index(drop=True)
            assert not set(discovery.source_row_index) & set(
                confirmation.source_row_index
            )
            assert len(discovery) + len(confirmation) == len(table)
            drules, dscores = verify_oracle(discovery, attrs)
            dvalid = np.flatnonzero(np.isfinite(dscores))
            result = engine.run_ds_mpga_v3_cached(discovery, attrs, random_state=seed)
            assert result["total_evaluation_requests"] == 5400
            dbudget = min(int(result["actual_evaluations"]), len(drules))
            run = base | {
                "discovery_n": len(discovery),
                "confirmation_n": len(confirmation),
                "actual_evaluations": result["actual_evaluations"],
                "rule_space": len(drules),
                "runtime_seconds": result["runtime_seconds"],
            }
            for name, frame in [
                ("discovery", discovery),
                ("confirmation", confirmation),
            ]:
                run[name + "_indices_sha256"] = hashlib.sha256(
                    frame.source_row_index.to_numpy(dtype=np.int64).tobytes()
                ).hexdigest()
            data["confirmation_runs"].append(run)
            for side in ["max", "min"]:
                selected = [
                    (
                        "DS-MPGA",
                        -1,
                        tuple(sorted(result[side + "_itemset"].split(", "))),
                    ),
                    ("Exact", -1, drules[chosen(dscores, dvalid, side)]),
                ]
                for repeat in range(20):
                    ix = np.random.default_rng(
                        300000 + seed * 100 + repeat
                    ).permutation(len(drules))[:dbudget]
                    i = chosen(dscores, ix, side)
                    selected.append(
                        ("Random", repeat, drules[i] if i is not None else None)
                    )
                for method, repeat, rule in selected:
                    cr = base | {
                        "method": method,
                        "repeat": repeat,
                        "direction": side,
                        "rule": json.dumps(rule),
                        "budget": dbudget if method != "Exact" else len(drules),
                    }
                    if rule is None:
                        cr["selection_defined"] = False
                    else:
                        cr["selection_defined"] = True
                        for name, frame in [
                            ("discovery", discovery),
                            ("confirmation", confirmation),
                        ]:
                            cr.update(
                                {
                                    name + "_" + k: v
                                    for k, v in evaluate_fixed(frame, rule).items()
                                }
                            )
                        cr["cv_change"] = cr["confirmation_cv"] - cr["discovery_cv"]
                        cr["direction_agrees"] = bool(
                            cr["confirmation_signed_difference"]
                            * cr["discovery_signed_difference"]
                            > 0
                        )
                        if method == "DS-MPGA":
                            assert np.isclose(
                                cr["discovery_cv"],
                                result[side + "_discrepancy_score"],
                                atol=1e-12,
                                rtol=0,
                            )
                    data["confirmation"].append(cr)
        data["optimality"].append(record)
        completed.add(key)
        # Commit the completion list last so interrupted batches can be detected.
        if (number + 1) % 12 == 0 or number + 1 == len(details):
            for name in [
                "random_baseline",
                "confirmation",
                "confirmation_runs",
                "optimality",
            ]:
                atomic(data[name], paths[name])
            print(
                f'{len(completed)}/{len(details)} tables; {len(data["confirmation_runs"])} confirmation searches',
                flush=True,
            )
    assert len(data["optimality"]) == len(details)
    assert len(data["random_baseline"]) == 20 * len(details)
    assert len(data["confirmation_runs"]) == len(details[details.seed.lt(30)])
    for name in ["random_baseline", "confirmation", "confirmation_runs", "optimality"]:
        atomic(data[name], paths[name])
    (out / "validation.json").write_text(
        json.dumps(
            {
                "status": "passed",
                "tables": len(details),
                "random_search_repetitions": len(data["random_baseline"]),
                "confirmation_searches": len(data["confirmation_runs"]),
                "confirmation_rule_evaluations": len(data["confirmation"]),
                "synthetic_oracle_test": "all 26 rules compared with original row-mask scorer",
                "benchmark_oracle_checks": "up to 31 rules per prediction table and discovery half",
                "exact_bound_checks": "all canonical max/min scores",
                "disjoint_confirmation": "source indices verified for every split",
                "code_sha256": sha(Path(__file__)),
            },
            indent=2,
        )
    )
    print("JOURNAL EXTENSION COMPLETE", flush=True)


if __name__ == "__main__":
    main()
