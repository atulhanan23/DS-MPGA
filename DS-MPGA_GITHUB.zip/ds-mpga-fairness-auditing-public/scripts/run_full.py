"""Run retained experiment drivers in a new workspace with separately supplied inputs."""

from pathlib import Path
import argparse, json, shutil, subprocess, sys

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument(
        "--family",
        choices=["primary", "ablation", "sensitivity", "references", "scaling", "all"],
        default="all",
    )
    args = parser.parse_args()
    if not args.run_id.replace("-", "").replace("_", "").isalnum():
        parser.error("Use letters, digits, underscores or hyphens for run-id.")
    dest = ROOT / "outputs/full" / args.run_id
    if dest.exists():
        parser.error("Choose a new run-id; existing results are never overwritten.")
    inputs = args.input_root.resolve()
    needed = []
    if args.family in ["primary", "all"]:
        for name in [
            "adult_modeling_data.csv",
            "compas_modeling_data_fixed.csv",
            "german_modeling_data.csv",
        ]:
            matches = list((inputs / "archive/imported").rglob(name))
            if len(matches) != 1:
                needed.append("archive/imported/**/" + name)
    if args.family in ["ablation", "all"]:
        if not (inputs / "prepared_data/ablation_corrected_v1/manifest.json").is_file():
            needed.append(
                "prepared_data/ablation_corrected_v1/manifest.json and its prediction tables"
            )
    if args.family in ["sensitivity", "references"]:
        if not (
            inputs
            / "results/final_evidence_v1/four_classifier_100seeds_all_details.csv"
        ).is_file():
            needed.append(
                "results/final_evidence_v1/four_classifier_100seeds_all_details.csv and its prepared_data tables"
            )
    if needed:
        parser.error("Required retained inputs are not available: " + "; ".join(needed))
    dest.mkdir(parents=True)
    for folder in ["src", "scripts", "configs", "docs"]:
        shutil.copytree(
            ROOT / folder,
            dest / folder,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
        )
    for folder in ["archive", "prepared_data"]:
        if (inputs / folder).is_dir():
            shutil.copytree(inputs / folder, dest / folder)
    if args.family in ["sensitivity", "references"]:
        shutil.copytree(
            inputs / "results/final_evidence_v1", dest / "results/final_evidence_v1"
        )
    stages = {
        "primary": ["run_xgboost", "run_remaining_classifiers", "build_final_evidence"],
        "ablation": ["run_ablation"],
        "sensitivity": ["run_sensitivity"],
        "references": [
            "run_journal_extension",
            "summarize_journal_extension",
            "analyze_intersectional",
        ],
        "scaling": ["run_large_space", "summarize_large_space"],
    }
    chosen = list(stages) if args.family == "all" else [args.family]
    commands = [driver for family in chosen for driver in stages[family]]
    if args.family == "all":
        commands.append("final_statistics")
    (dest / "run_plan.json").write_text(
        json.dumps(dict(family=args.family, drivers=commands), indent=2)
    )
    for driver in commands:
        with (dest / (driver + ".log")).open("w", encoding="utf-8") as log:
            subprocess.run(
                [sys.executable, "-u", str(dest / "scripts" / f"{driver}.py")],
                cwd=dest,
                stdout=log,
                stderr=subprocess.STDOUT,
                check=True,
            )
        print("Completed", driver, flush=True)
    print("New experiment workspace:", dest)


if __name__ == "__main__":
    main()
