"""Matched Wilcoxon tests and rank-biserial effects on frozen result families."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import itertools, json
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon, rankdata
from statsmodels.stats.multitest import multipletests
from scripts.run_xgboost import sha


def paired(first, second):
    joined = first.rename("a").to_frame().join(second.rename("b"), how="inner").dropna()
    assert len(joined) == len(first.dropna()) == len(second.dropna())
    delta = np.round(joined.a.to_numpy() - joined.b.to_numpy(), 12)
    nz = delta[delta != 0]
    if len(nz) == 0:
        stat, p, effect = 0.0, 1.0, 0.0
    else:
        test = wilcoxon(
            delta, zero_method="wilcox", alternative="two-sided", method="asymptotic"
        )
        stat, p = float(test.statistic), float(test.pvalue)
        ranks = rankdata(abs(nz))
        effect = float((ranks[nz > 0].sum() - ranks[nz < 0].sum()) / ranks.sum())
    med = float(np.median(delta))
    return {
        "n_pairs": len(joined),
        "n_nonzero": len(nz),
        "statistic": stat,
        "p_raw": p,
        "first_median": float(joined.a.median()),
        "second_median": float(joined.b.median()),
        "median_paired_difference": med,
        "mean_paired_difference": float(delta.mean()),
        "rank_biserial": effect,
        "direction": (
            "first larger"
            if med > 0
            else "second larger" if med < 0 else "median difference zero"
        ),
    }


def main():
    assert paired(pd.Series([1.0, 1.0]), pd.Series([1.0, 1.0]))["rank_biserial"] == 0
    assert (
        paired(pd.Series([2.0, 3.0, 4.0]), pd.Series([1.0, 1.0, 1.0]))["rank_biserial"]
        == 1
    )
    sources = {
        "classifier": ROOT
        / "results/final_evidence_v1/four_classifier_100seeds_all_details.csv",
        "ablation": ROOT
        / "results/ablation_corrected_v1/full_30seeds/ablation_ds_mpga_v3_cached_30seeds_final.csv",
        "sensitivity": ROOT
        / "results/sensitivity_v1/full_30seeds/sensitivity_final.csv",
    }
    frames = {name: pd.read_csv(p) for name, p in sources.items()}
    assert [len(frames[k]) for k in ["classifier", "ablation", "sensitivity"]] == [
        1200,
        450,
        1800,
    ]
    rows = []

    def add(family, dataset, classifier, metric, a, b, first, second):
        result = paired(a, b)
        assert result["n_pairs"] in [30, 100]
        rows.append(
            dict(
                family=family,
                dataset=dataset,
                classifier=classifier,
                metric=metric,
                first=first,
                second=second,
                **result
            )
        )

    for dataset, g in frames["classifier"].groupby("dataset"):
        for a, b in itertools.combinations(sorted(g.classifier.unique()), 2):
            for family, metrics in [
                ("classifier_predictive", ["accuracy", "f1_score"]),
                (
                    "classifier_discovery",
                    [
                        "max_discrepancy_score",
                        "min_discrepancy_score",
                        "discrepancy_gap",
                    ],
                ),
            ]:
                for metric in metrics:
                    x = g[g.classifier == a].set_index("seed")[metric]
                    y = g[g.classifier == b].set_index("seed")[metric]
                    assert x.index.is_unique and y.index.is_unique
                    add(family, dataset, "paired classifiers", metric, x, y, a, b)
    for dataset, g in frames["ablation"].groupby("dataset"):
        full = "Full DS-MPGA v3 Cached"
        for variant in sorted(set(g.configuration) - {full}):
            for family, metrics in [
                (
                    "ablation_discovery",
                    [
                        "max_discrepancy_score",
                        "min_discrepancy_score",
                        "discrepancy_gap",
                    ],
                ),
                ("ablation_efficiency", ["runtime_seconds", "actual_evaluations"]),
            ]:
                for metric in metrics:
                    if variant == "Max-only search" and metric in [
                        "min_discrepancy_score",
                        "discrepancy_gap",
                    ]:
                        continue
                    add(
                        family,
                        dataset,
                        "fixed RF predictions",
                        metric,
                        g[g.configuration == full].set_index("seed")[metric],
                        g[g.configuration == variant].set_index("seed")[metric],
                        full,
                        variant,
                    )
    for (dataset, classifier), g in frames["sensitivity"].groupby(
        ["dataset", "classifier"]
    ):
        for variant in sorted(set(g.setting) - {"reference"}):
            for family, metrics in [
                (
                    "sensitivity_discovery",
                    [
                        "max_discrepancy_score",
                        "min_discrepancy_score",
                        "discrepancy_gap",
                    ],
                ),
                ("sensitivity_efficiency", ["runtime_seconds", "actual_evaluations"]),
            ]:
                for metric in metrics:
                    add(
                        family,
                        dataset,
                        classifier,
                        metric,
                        g[g.setting == "reference"].set_index("seed")[metric],
                        g[g.setting == variant].set_index("seed")[metric],
                        "reference",
                        variant,
                    )
    tests = pd.DataFrame(rows)
    for family, indices in tests.groupby("family").groups.items():
        tests.loc[indices, "p_holm"] = multipletests(
            tests.loc[indices, "p_raw"], method="holm"
        )[1]
        tests.loc[indices, "family_size"] = len(indices)
    tests["significant_holm_005"] = tests.p_holm < 0.05
    assert (
        len(tests) == 384
        and tests[["p_raw", "p_holm", "rank_biserial"]].notna().all().all()
    )
    assert tests.p_holm.ge(tests.p_raw - 1e-12).all()
    out = ROOT / "results/final_statistics_v1"
    out.mkdir(parents=True, exist_ok=True)
    tests.to_csv(out / "paired_tests_all.csv", index=False)
    tests.groupby("family").agg(
        tests=("p_raw", "size"), significant=("significant_holm_005", "sum")
    ).reset_index().to_csv(out / "test_family_summary.csv", index=False)
    manifest = {
        "status": "passed",
        "tests": len(tests),
        "effect_size": "matched-pairs rank-biserial, first minus second; zero-only differences set to 0",
        "wilcoxon": "two-sided asymptotic; zero_method=wilcox; paired differences rounded to 12 decimals",
        "multiplicity": "Holm within six separately defined outcome families",
        "limitations": "Overlapping repeated splits are not independent populations. Post-selected rule metrics are descriptive. No causality or mitigation inference.",
        "source_sha256": {str(p.relative_to(ROOT)): sha(p) for p in sources.values()},
        "statistics_code_sha256": sha(Path(__file__)),
    }
    (out / "frozen_inputs.json").write_text(json.dumps(manifest, indent=2))
    print(tests.groupby("family").significant_holm_005.agg(["size", "sum"]).to_string())


if __name__ == "__main__":
    main()
