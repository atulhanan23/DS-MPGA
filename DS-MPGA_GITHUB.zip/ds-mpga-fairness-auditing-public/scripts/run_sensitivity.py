"""One-factor sensitivity across four classifiers, three datasets, 30 seeds."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.preprocessing.paths import prediction_path
import argparse, itertools, json, math
import numpy as np
import pandas as pd
from src.algorithms import ds_mpga as engine
from scripts.run_xgboost import DATASETS, sha
from scripts.run_ablation import atomic_csv

SETTINGS = {
    "reference": (0.10, 3),
    "support_005": (0.05, 3),
    "support_020": (0.20, 3),
    "length_1": (0.10, 1),
    "length_2": (0.10, 2),
}


def run(table, attrs, seed, support, length):
    original_metric = engine.calculate_subgroup_metrics_v2
    original_eval = engine.evaluate_itemset_v2
    counts = {"unique_valid_candidates": 0, "valid_candidate_requests": 0}

    def metric(*args, **kwargs):
        result = original_metric(*args, **kwargs)
        if result is not None:
            counts["unique_valid_candidates"] += 1
        return result

    def evaluate(*args, **kwargs):
        result = original_eval(*args, **kwargs)
        if result[0] is not None:
            counts["valid_candidate_requests"] += 1
        return result

    engine.calculate_subgroup_metrics_v2 = metric
    engine.evaluate_itemset_v2 = evaluate
    try:
        result = engine.run_ds_mpga_v3_cached(
            table, attrs, random_state=seed, min_support=support, max_length=length
        )
    finally:
        engine.calculate_subgroup_metrics_v2 = original_metric
        engine.evaluate_itemset_v2 = original_eval
    levels = [table[a].nunique() for a in attrs]
    size = sum(
        math.prod(levels[i] for i in combo)
        for k in range(1, length + 1)
        for combo in itertools.combinations(range(len(attrs)), k)
    )
    return result | counts | {"syntactic_rule_space": size}


def validate(row, table, attrs):
    assert row["total_evaluation_requests"] == 5400
    assert row["actual_evaluations"] + row["cache_hits"] == 5400
    assert 0 < row["unique_valid_candidates"] <= row["actual_evaluations"] <= 5400
    assert row["unique_valid_candidates"] <= row["valid_candidate_requests"] <= 5400
    for side in ["max", "min"]:
        rules = row[f"{side}_itemset"].split(", ")
        assert 1 <= len(rules) <= row["max_length"]
        assert len(set(x.split(" = ", 1)[0] for x in rules)) == len(rules)
        m = engine.calculate_subgroup_metrics_v2(
            table, rules, min_support=row["support_threshold"]
        )
        assert m is not None
        for k, v in m.items():
            assert np.isclose(v, row[f"{side}_{k}"], atol=1e-12, rtol=0)
    assert np.isclose(
        row["discrepancy_gap"],
        row["max_discrepancy_score"] - row["min_discrepancy_score"],
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()
    source = ROOT / "results/final_evidence_v1/four_classifier_100seeds_all_details.csv"
    details = pd.read_csv(source)
    seeds = [0] if args.smoke else list(range(30))
    selected = details[details.seed.isin(seeds)]
    out = (
        ROOT
        / "results/sensitivity_v1"
        / ("smoke_seed0" if args.smoke else "full_30seeds")
    )
    out.mkdir(parents=True, exist_ok=True)
    provenance = {
        "source_sha256": sha(source),
        "settings": SETTINGS,
        "seeds": seeds,
        "code": sha(Path(__file__)),
        "engine_sha256": sha(ROOT / "src/algorithms/ds_mpga.py"),
        "instrumentation": "Counts cache-miss valid metrics and valid requests; wrappers consume no RNG. Timing includes the same wrappers in all settings.",
    }
    pp = out / "provenance.json"
    # Normalize tuple/list representation for checkpoint comparison.
    provenance = json.loads(json.dumps(provenance))
    if pp.exists():
        assert json.loads(pp.read_text()) == provenance
    else:
        pp.write_text(json.dumps(provenance, indent=2))
    cp = out / "sensitivity_checkpoint.csv"
    rows = pd.read_csv(cp).to_dict("records") if cp.exists() else []
    keys = ["dataset", "classifier", "seed", "setting"]
    done = {tuple(r[k] for k in keys) for r in rows}
    assert len(done) == len(rows)
    expected = {
        (r.dataset, r.classifier, r.seed, setting)
        for r in selected.itertuples()
        for setting in SETTINGS
    }
    assert done <= expected
    for canonical in selected.to_dict("records"):
        table = pd.read_csv(prediction_path(ROOT, canonical["prediction_file"]))
        attrs = DATASETS[canonical["dataset"]][2]
        assert (
            sha(prediction_path(ROOT, canonical["prediction_file"])) == canonical["prediction_sha256"]
        )
        for setting, (support, length) in SETTINGS.items():
            key = (
                canonical["dataset"],
                canonical["classifier"],
                canonical["seed"],
                setting,
            )
            if key in done:
                continue
            result = run(table, attrs, int(canonical["seed"]), support, length)
            row = {
                k: canonical[k]
                for k in [
                    "dataset",
                    "classifier",
                    "seed",
                    "prediction_file",
                    "prediction_sha256",
                ]
            }
            row.update(
                setting=setting, support_threshold=support, max_length=length, **result
            )
            validate(row, table, attrs)
            if setting == "reference":
                for k in [
                    "max_itemset",
                    "min_itemset",
                    "max_discrepancy_score",
                    "min_discrepancy_score",
                    "actual_evaluations",
                    "cache_hits",
                ]:
                    if isinstance(result[k], str):
                        assert result[k] == canonical[k]
                    else:
                        assert np.isclose(result[k], canonical[k], atol=1e-12, rtol=0)
            rows.append(row)
            done.add(key)
            atomic_csv(pd.DataFrame(rows), cp)
            if len(rows) % 10 == 0:
                print(f"{len(rows)}/{len(selected)*5} | {key}", flush=True)
    assert len(rows) == len(selected) * 5 and done == expected
    final = pd.DataFrame(rows)
    assert not final.duplicated(keys).any()
    for _, g in final.groupby(["dataset", "classifier", "setting"]):
        assert set(g.seed) == set(seeds)
    atomic_csv(final, out / "sensitivity_final.csv")
    metrics = [
        "max_discrepancy_score",
        "min_discrepancy_score",
        "discrepancy_gap",
        "max_support",
        "runtime_seconds",
        "actual_evaluations",
        "cache_hit_rate",
        "unique_valid_candidates",
        "valid_candidate_requests",
        "syntactic_rule_space",
    ]
    agg = {"completed_seeds": ("seed", "nunique")}
    for m in metrics:
        agg.update({m + "_mean": (m, "mean"), m + "_std": (m, "std")})
    final.groupby(
        ["dataset", "classifier", "setting", "support_threshold", "max_length"]
    ).agg(**agg).reset_index().to_csv(out / "sensitivity_summary.csv", index=False)
    (out / "validation.json").write_text(
        json.dumps(
            {
                "status": "passed",
                "jobs": len(rows),
                "groups": 60,
                "seeds_per_group": len(seeds),
                "reference_matches_canonical": True,
            },
            indent=2,
        )
    )
    print("SENSITIVITY VALIDATED", out, flush=True)


if __name__ == "__main__":
    main()
