"""Corrected, checkpointed XGBoost + canonical DS-MPGA v3 evaluation."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.preprocessing.paths import prediction_path
import argparse
import hashlib
import json
import platform
import time
import numpy as np
import pandas as pd
import sklearn
import xgboost
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score
from xgboost import XGBClassifier
from src.algorithms.ds_mpga import run_ds_mpga_v3_cached, calculate_subgroup_metrics_v2
from scripts.run_ablation import validate_row, atomic_csv

DATASETS = {
    "Adult Income": (
        "adult",
        "adult_modeling_data.csv",
        [
            "sex",
            "race",
            "age_group",
            "education",
            "marital-status",
            "hours_per_week_group",
        ],
    ),
    "COMPAS": (
        "compas",
        "compas_modeling_data_fixed.csv",
        ["sex", "race", "age_cat", "c_charge_degree", "priors_count_group"],
    ),
    "German Credit": (
        "german",
        "german_modeling_data.csv",
        [
            "checking_status",
            "savings_status",
            "employment",
            "sex_group",
            "age_group",
            "duration_group",
            "credit_amount_group",
        ],
    ),
}
PARAMS = dict(
    n_estimators=100,
    max_depth=4,
    learning_rate=0.1,
    random_state=42,
    eval_metric="logloss",
    n_jobs=-1,
)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source(name):
    found = list((ROOT / "archive/imported").rglob(name))
    assert len(found) == 1, found
    return found[0]


def prepare(dataset):
    slug, filename, attrs = DATASETS[dataset]
    original = pd.read_csv(source(filename))
    df = original.dropna().reset_index(drop=True)
    assert len(df) == len(original), "Missing rows need explicit provenance review"
    y = df.target_binary.astype(int)
    assert set(y.unique()) == {0, 1}
    if dataset == "Adult Income":
        assert y.equals((df.target.str.strip() == ">50K").astype(int))
    elif dataset == "COMPAS":
        assert y.equals((df.two_year_recid == 0).astype(int))
    else:
        assert y.equals((df.target == 1).astype(int))
    excluded = [
        c
        for c in ["target_binary", "target", "two_year_recid", "favourable_label"]
        if c in df
    ]
    x = df.drop(columns=excluded)
    assert not [
        c
        for c in x
        if any(s in c.lower() for s in ["target", "recid", "label", "score"])
    ]
    encoded = pd.get_dummies(x, drop_first=False)
    mapping = {f"f{i:04d}": str(c) for i, c in enumerate(encoded.columns)}
    # Values are exactly representable in float32 for these prepared datasets.
    values = encoded.to_numpy(dtype=np.float32)
    assert np.isfinite(values).all()
    assert np.array_equal(values.astype(np.float64), encoded.to_numpy(dtype=np.float64))
    safe = pd.DataFrame(values, columns=list(mapping), index=encoded.index)
    assert df[attrs].notna().all().all()
    return df, y, safe, mapping, excluded


def verify_prediction_table(table, row, attrs):
    assert table.source_row_index.is_unique
    assert table[attrs + ["prediction", "true_label"]].notna().all().all()
    assert set(table.prediction.unique()) <= {0, 1}
    assert np.isclose(
        accuracy_score(table.true_label, table.prediction), row["accuracy"]
    )
    assert np.isclose(f1_score(table.true_label, table.prediction), row["f1_score"])
    for side in ["max", "min"]:
        rules = row[f"{side}_itemset"].split(", ")
        assert 1 <= len(rules) <= 3
        assert len(set(r.split(" = ", 1)[0] for r in rules)) == len(rules)
        metrics = calculate_subgroup_metrics_v2(table, rules)
        assert metrics is not None
        for k, value in metrics.items():
            assert np.isclose(value, row[f"{side}_{k}"], atol=1e-12, rtol=0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    seeds = [0] if args.smoke else list(range(100))
    mode = "smoke_seed0" if args.smoke else "full_100seeds"
    out = ROOT / "results/xgboost_corrected_v1" / mode
    data_out = ROOT / "prepared_data/xgboost_corrected_v1" / mode
    out.mkdir(parents=True, exist_ok=True)
    data_out.mkdir(parents=True, exist_ok=True)
    sources = {
        name: {
            "file": str(source(spec[1]).relative_to(ROOT)),
            "sha256": sha(source(spec[1])),
        }
        for name, spec in DATASETS.items()
    }
    provenance = {
        "version": "xgboost_corrected_v1",
        "sources": sources,
        "seeds": seeds,
        "model_parameters": PARAMS,
        "split": {
            "test_size": 0.30,
            "stratify": "target_binary",
            "random_state": "seed",
        },
        "search_random_state": "seed",
        "model_random_state": 42,
        "search_settings": {
            "min_support": 0.10,
            "max_length": 3,
            "n_populations": 3,
            "population_size": 30,
            "generations": 30,
            "mutation_rate": 0.30,
            "migration_interval": 5,
            "migration_size": 3,
        },
        "encoding": "Notebook safe builder get_dummies before split; lossless float32 conversion and safe feature names f0000 etc.",
        "timing": "runtime_seconds is canonical search only; training_seconds recorded separately",
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "sklearn": sklearn.__version__,
            "xgboost": xgboost.__version__,
            "platform": platform.platform(),
        },
        "code_hashes": {
            n: sha(
                ROOT
                / (
                    "src/algorithms/ds_mpga.py"
                    if n == "ablation_engine.py"
                    else "scripts/" + n
                )
            )
            for n in ["run_xgboost.py", "ablation_engine.py", "run_ablation.py"]
        },
    }
    pp = out / "provenance.json"
    if pp.exists():
        assert (
            json.loads(pp.read_text()) == provenance
        ), "Provenance changed; create a new version"
    else:
        pp.write_text(json.dumps(provenance, indent=2))
    checkpoint = out / "xgboost_ds_mpga_v3_cached_100seeds_checkpoint.csv"
    rows = pd.read_csv(checkpoint).to_dict("records") if checkpoint.exists() else []
    expected = {(dataset, seed) for dataset in DATASETS for seed in seeds}
    done = set()
    for row in rows:
        key = row["dataset"], row["seed"]
        assert key in expected and key not in done
        validate_row(dict(row, configuration="Full DS-MPGA v3 Cached"))
        assert sha(prediction_path(ROOT, row["prediction_file"])) == row["prediction_sha256"]
        done.add(key)
    for dataset, (slug, filename, attrs) in DATASETS.items():
        df, y, safe, mapping, excluded = prepare(dataset)
        (out / f"{slug}_feature_map.json").write_text(
            json.dumps(
                {
                    "safe_to_original": mapping,
                    "excluded_columns": excluded,
                    "subgroup_attributes": attrs,
                },
                indent=2,
            )
        )
        for seed in seeds:
            if (dataset, seed) in done:
                continue
            xtrain, xtest, ytrain, ytest, itrain, itest = train_test_split(
                safe, y, df.index, test_size=0.30, random_state=seed, stratify=y
            )
            assert not set(itrain) & set(itest)
            assert set(itrain) | set(itest) == set(df.index)
            assert ytest.index.equals(pd.Index(itest))
            clf = XGBClassifier(**PARAMS)
            start = time.perf_counter()
            clf.fit(xtrain, ytrain)
            pred = clf.predict(xtest)
            train_seconds = time.perf_counter() - start
            table = df.loc[itest, attrs].reset_index(drop=True)
            table["prediction"] = pred
            table["true_label"] = ytest.to_numpy()
            table["source_row_index"] = np.asarray(itest)
            result = run_ds_mpga_v3_cached(table, attrs, random_state=seed)
            row = {
                "dataset": dataset,
                "classifier": "XGBoost",
                "seed": seed,
                "accuracy": accuracy_score(ytest, pred),
                "f1_score": f1_score(ytest, pred),
                "training_seconds": train_seconds,
                **result,
            }
            validate_row(dict(row, configuration="Full DS-MPGA v3 Cached"))
            verify_prediction_table(table, row, attrs)
            dest = data_out / f"{slug}_seed{seed:03d}_predictions.csv.gz"
            table.to_csv(dest, index=False, compression={"method": "gzip", "mtime": 0})
            row["prediction_file"] = str(dest.relative_to(ROOT))
            row["prediction_sha256"] = sha(dest)
            row["train_index_sha256"] = hashlib.sha256(
                np.asarray(itrain, dtype="<i8").tobytes()
            ).hexdigest()
            row["test_index_sha256"] = hashlib.sha256(
                np.asarray(itest, dtype="<i8").tobytes()
            ).hexdigest()
            row["train_rows"], row["test_rows"] = len(itrain), len(itest)
            if seed == 0:
                clf.save_model(out / f"{slug}_seed000_model.ubj")
                (out / f"{slug}_resolved_model_config.json").write_text(
                    clf.get_booster().save_config()
                )
            rows.append(row)
            done.add((dataset, seed))
            atomic_csv(pd.DataFrame(rows), checkpoint)
            print(
                f'{len(done)}/{len(expected)} | {dataset} | seed {seed} | accuracy {row["accuracy"]:.4f} | Max CV {row["max_discrepancy_score"]:.4f} | train {train_seconds:.2f}s | search {row["runtime_seconds"]:.2f}s',
                flush=True,
            )
    assert done == expected
    # Independently reload and verify every saved prediction table and split.
    for row in rows:
        dataset = row["dataset"]
        attrs = DATASETS[dataset][2]
        path = prediction_path(ROOT, row["prediction_file"])
        assert sha(path) == row["prediction_sha256"]
        table = pd.read_csv(path)
        verify_prediction_table(table, row, attrs)
    final = pd.DataFrame(rows)
    assert not final.duplicated(["dataset", "classifier", "seed"]).any()
    atomic_csv(final, out / "xgboost_ds_mpga_v3_cached_100seeds_all_details.csv")
    (out / "validation.json").write_text(
        json.dumps(
            {
                "status": "passed",
                "rows": len(rows),
                "expected_rows": len(expected),
                "smoke_only": args.smoke,
                "unique_seed_sets": seeds,
                "direct_rule_metric_recomputation": True,
                "prediction_tables_saved_and_hashed": True,
                "target_columns_excluded": True,
                "train_test_disjoint": True,
            },
            indent=2,
        )
    )
    print("VALIDATED", out, flush=True)


if __name__ == "__main__":
    main()
