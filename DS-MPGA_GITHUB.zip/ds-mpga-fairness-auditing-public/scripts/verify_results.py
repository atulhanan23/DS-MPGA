"""Check the supplied aggregate evidence without rerunning search or training."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import hashlib, json
import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests


def main():
    data = ROOT / "results/validated"
    out = ROOT / "outputs/evidence_checks"
    out.mkdir(parents=True, exist_ok=True)
    main = pd.read_csv(data / "main/primary_1200_runs.csv")
    rules = pd.read_csv(data / "rules/selected_rules_2400.csv")
    exact = pd.read_csv(data / "search_references/exact_per_run_1200.csv")
    stats = pd.read_csv(data / "statistics/statistical_audit.csv")
    checks = {
        "primary_runs": len(main) == 1200,
        "selected_rules": len(rules) == 2400,
        "unique_primary_keys": not main.duplicated(
            ["dataset", "classifier", "seed"]
        ).any(),
        "intersectional_selections": int(rules.is_intersectional.sum()) == 607,
        "max_exact_attainment": int(exact.max_exact_hit.sum()) == 1067,
        "min_exact_attainment": int(exact.min_exact_hit.sum()) == 954,
        "statistical_comparisons": len(stats) == 384,
    }
    families = []
    for family, g in stats.groupby("family"):
        p = multipletests(g.p_raw, method="holm")[1]
        error = float(np.max(np.abs(p - g.p_holm.to_numpy())))
        checks["holm_" + family] = error < 1e-12
        families.append(
            dict(
                family=family,
                tests=len(g),
                significant=int((p < 0.05).sum()),
                max_error=error,
            )
        )
    manifest = ROOT / "results/validated_manifest.json"
    if manifest.exists():
        checks["evidence_hashes"] = all(
            hashlib.sha256((ROOT / entry["path"]).read_bytes()).hexdigest()
            == entry["sha256"]
            for entry in json.loads(manifest.read_text())
        )
    result = dict(
        scope="Saved evidence and Holm adjustment replay; no new full experiment.",
        checks=checks,
        families=families,
    )
    (out / "verification.json").write_text(json.dumps(result, indent=2))
    assert all(checks.values()), result
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
