"""Regenerate descriptive summaries from the frozen run-level evidence."""

from pathlib import Path
import sys, json

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import pandas as pd


def main():
    data = ROOT / "results/validated"
    out = ROOT / "outputs/summaries"
    out.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(data / "main/primary_1200_runs.csv")
    metrics = [
        "accuracy",
        "f1_score",
        "max_discrepancy_score",
        "min_discrepancy_score",
        "discrepancy_gap",
        "runtime_seconds",
        "actual_evaluations",
        "cache_hit_rate",
    ]
    summary = df.groupby(["dataset", "classifier"])[metrics].agg(["mean", "std"])
    summary.columns = ["_".join(c) for c in summary.columns]
    summary.to_csv(out / "primary.csv")
    rules = pd.read_csv(data / "rules/selected_rules_2400.csv")
    rules.groupby(["dataset", "classifier", "direction"]).agg(
        selections=("is_intersectional", "size"),
        intersectional=("is_intersectional", "sum"),
    ).to_csv(out / "intersection_counts.csv")
    exact = pd.read_csv(data / "search_references/exact_per_run_1200.csv")
    exact.groupby(["dataset", "classifier"])[
        ["max_exact_hit", "min_exact_hit"]
    ].mean().to_csv(out / "exact_attainment.csv")
    tests = pd.read_csv(data / "statistics/statistical_audit.csv")
    tests.assign(significant=tests.p_holm.lt(0.05)).groupby("family").agg(
        tests=("p_raw", "size"), significant=("significant", "sum")
    ).to_csv(out / "statistical_families.csv")
    print("Summaries:", out)


if __name__ == "__main__":
    main()
