"""Freeze fully traceable classifier rows, subgroup rules and post-hoc metrics."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.preprocessing.paths import prediction_path
import hashlib, json
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from scripts.run_xgboost import DATASETS, prepare, sha, verify_prediction_table
from scripts.run_ablation import validate_row

OUT = ROOT / "results/final_evidence_v1"


def conditional_metrics(y, p, mask):
    result = {}
    for label, m in [("subgroup", mask), ("outside", ~mask)]:
        yy, pp = y[m], p[m]
        counts = {
            "tp": int(((yy == 1) & (pp == 1)).sum()),
            "fp": int(((yy == 0) & (pp == 1)).sum()),
            "tn": int(((yy == 0) & (pp == 0)).sum()),
            "fn": int(((yy == 1) & (pp == 0)).sum()),
        }
        result.update({f"{label}_{k}": v for k, v in counts.items()})
        for metric, den in [
            ("tpr", counts["tp"] + counts["fn"]),
            ("fpr", counts["fp"] + counts["tn"]),
            ("ppv", counts["tp"] + counts["fp"]),
        ]:
            num = counts["fp"] if metric == "fpr" else counts["tp"]
            result[f"{label}_{metric}"] = num / den if den else np.nan
            result[f"{label}_{metric}_denominator"] = den
    for metric in ["tpr", "fpr", "ppv"]:
        a, b = result[f"subgroup_{metric}"], result[f"outside_{metric}"]
        reason = "; ".join(
            f"{side} denominator is zero"
            for side in ["subgroup", "outside"]
            if result[f"{side}_{metric}_denominator"] == 0
        )
        result[f"{metric}_gap_reason"] = reason
        result[f"{metric}_signed_difference"] = a - b if not reason else np.nan
        result[f"{metric}_gap"] = abs(a - b) if not reason else np.nan
    reasons = [
        result[f"{m}_gap_reason"] for m in ["tpr", "fpr"] if result[f"{m}_gap_reason"]
    ]
    result["equalized_odds_gap"] = (
        max(result["tpr_gap"], result["fpr_gap"]) if not reasons else np.nan
    )
    result["equalized_odds_gap_reason"] = "; ".join(reasons)
    return result


def metric_checks():
    y = np.array([1, 1, 0, 0, 1, 1, 0, 0])
    p = np.array([1, 0, 1, 0, 1, 1, 0, 0])
    m = np.arange(8) < 4
    r = conditional_metrics(y, p, m)
    assert (
        r["tpr_gap"] == 0.5
        and r["fpr_gap"] == 0.5
        and r["ppv_gap"] == 0.5
        and r["equalized_odds_gap"] == 0.5
    )
    r = conditional_metrics(np.ones(4), np.zeros(4), np.array([1, 1, 0, 0], dtype=bool))
    assert r["tpr_gap"] == 0 and np.isnan(r["fpr_gap"]) and np.isnan(r["ppv_gap"])
    assert (
        r["fpr_gap_reason"]
        and r["ppv_gap_reason"]
        and np.isnan(r["equalized_odds_gap"])
    )


def main():
    metric_checks()
    OUT.mkdir(parents=True, exist_ok=True)
    a = (
        ROOT
        / "results/classifiers_reconstructed_v1/full_100seeds/classifier_details_final.csv"
    )
    b = (
        ROOT
        / "results/xgboost_corrected_v1/full_100seeds/xgboost_ds_mpga_v3_cached_100seeds_all_details.csv"
    )
    combined = pd.concat([pd.read_csv(a), pd.read_csv(b)], ignore_index=True)
    keys = ["dataset", "classifier", "seed"]
    assert len(combined) == 1200 and not combined.duplicated(keys).any()
    assert combined.groupby(keys[:2]).ngroups == 12
    rules = []
    for dataset, (_, _, attrs) in DATASETS.items():
        df, y, _, _, _ = prepare(dataset)
        for classifier, group in combined[combined.dataset == dataset].groupby(
            "classifier"
        ):
            assert set(group.seed) == set(range(100))
            for row in group.to_dict("records"):
                validate_row(dict(row, configuration="Full DS-MPGA v3 Cached"))
                train, test = train_test_split(
                    np.arange(len(df)),
                    test_size=0.3,
                    random_state=int(row["seed"]),
                    stratify=y,
                )
                assert not set(train) & set(test)
                for label, indices in [("train", train), ("test", test)]:
                    assert (
                        hashlib.sha256(
                            np.asarray(indices, dtype="<i8").tobytes()
                        ).hexdigest()
                        == row[f"{label}_index_sha256"]
                    )
                path = prediction_path(ROOT, row["prediction_file"])
                assert sha(path) == row["prediction_sha256"]
                table = pd.read_csv(path)
                assert np.array_equal(table.source_row_index, test)
                assert np.array_equal(table.true_label, y.iloc[test])
                pd.testing.assert_frame_equal(
                    table[attrs],
                    df.loc[test, attrs].reset_index(drop=True),
                    check_dtype=False,
                )
                verify_prediction_table(table, row, attrs)
                for direction in ["max", "min"]:
                    conditions = row[f"{direction}_itemset"].split(", ")
                    mask = np.ones(len(table), dtype=bool)
                    for condition in conditions:
                        attr, value = condition.split(" = ", 1)
                        mask &= table[attr].astype(str).to_numpy() == value
                    entry = {
                        k: row[k]
                        for k in keys + ["prediction_file", "prediction_sha256"]
                    }
                    entry.update(
                        method="DS-MPGA v3 Cached",
                        direction=direction,
                        rule=row[f"{direction}_itemset"],
                        rule_key=json.dumps(sorted(conditions)),
                        rule_length=len(conditions),
                        support=float(mask.mean()),
                        metric_subgroup=float(table.prediction[mask].mean()),
                        metric_outside=float(table.prediction[~mask].mean()),
                        discrepancy_score=row[f"{direction}_discrepancy_score"],
                        **conditional_metrics(
                            table.true_label.to_numpy(),
                            table.prediction.to_numpy(),
                            mask,
                        ),
                    )
                    assert np.isclose(
                        abs(entry["metric_subgroup"] - entry["metric_outside"]),
                        entry["discrepancy_score"],
                    )
                    rules.append(entry)
            print("Verified", dataset, classifier, flush=True)
    combined.to_csv(OUT / "four_classifier_100seeds_all_details.csv", index=False)
    metrics = [
        "accuracy",
        "f1_score",
        "max_discrepancy_score",
        "min_discrepancy_score",
        "discrepancy_gap",
        "runtime_seconds",
        "actual_evaluations",
        "cache_hit_rate",
    ]
    agg = {"completed_seeds": ("seed", "nunique")}
    for m in metrics:
        agg.update({m + "_mean": (m, "mean"), m + "_std": (m, "std")})
    summary = combined.groupby(keys[:2]).agg(**agg).reset_index()
    summary.to_csv(OUT / "four_classifier_summary.csv", index=False)
    inv = pd.DataFrame(rules)
    assert len(inv) == 2400
    inv.to_csv(OUT / "verified_subgroups_all.csv", index=False)
    unique = []
    for key, g in inv.groupby(["dataset", "classifier", "direction", "rule_key"]):
        representative = (
            g.sort_values(
                ["discrepancy_score", "seed"], ascending=[key[2] == "min", True]
            )
            .iloc[0]
            .to_dict()
        )
        representative.update(
            discovery_seed_count=int(g.seed.nunique()),
            discovery_frequency=g.seed.nunique() / 100,
            discrepancy_mean=g.discrepancy_score.mean(),
            discrepancy_std=g.discrepancy_score.std(),
        )
        unique.append(representative)
    unique = pd.DataFrame(unique).sort_values(
        [
            "dataset",
            "classifier",
            "direction",
            "discrepancy_score",
            "discovery_seed_count",
        ],
        ascending=[True, True, True, False, False],
    )
    unique.to_csv(OUT / "verified_subgroups_unique.csv", index=False)
    unique[unique.direction == "max"].groupby(keys[:2]).head(1).to_csv(
        OUT / "subgroups_paper_top_max.csv", index=False
    )
    unique[(unique.direction == "max") & (unique.rule_length >= 2)].groupby(
        keys[:2]
    ).head(1).to_csv(OUT / "subgroups_paper_top_intersections.csv", index=False)
    post = []
    for key, g in inv.groupby(["dataset", "classifier", "direction"]):
        for metric in ["tpr_gap", "fpr_gap", "ppv_gap", "equalized_odds_gap"]:
            v = g[metric].dropna()
            post.append(
                dict(zip(["dataset", "classifier", "direction"], key))
                | {
                    "metric": metric,
                    "total_rules": len(g),
                    "valid_count": len(v),
                    "undefined_count": len(g) - len(v),
                    "mean": v.mean(),
                    "std": v.std(),
                    "median": v.median(),
                    "maximum": v.max(),
                }
            )
    pd.DataFrame(post).to_csv(OUT / "posthoc_fairness_summary.csv", index=False)
    historical = next(
        (ROOT / "archive/imported").rglob(
            "multi_classifier_ds_mpga_v3_cached_100seeds_no_xgboost_final.csv"
        )
    )
    merged = combined.merge(
        pd.read_csv(historical),
        on=keys,
        suffixes=("_local", "_historical"),
        validate="one_to_one",
    )
    comparison = merged[keys].copy()
    for m in ["accuracy", "f1_score", "max_discrepancy_score", "min_discrepancy_score"]:
        comparison[m + "_delta"] = merged[m + "_local"] - merged[m + "_historical"]
    comparison.to_csv(OUT / "historical_reconstruction_differences.csv", index=False)
    (OUT / "validation.json").write_text(
        json.dumps(
            {
                "status": "passed",
                "classifier_jobs": 1200,
                "verified_rules": 2400,
                "unique_rules": len(unique),
                "groups": 12,
                "seeds_per_group": 100,
                "posthoc_not_separate_search": True,
                "undefined_metric_cells": int(
                    inv[["tpr_gap", "fpr_gap", "ppv_gap", "equalized_odds_gap"]]
                    .isna()
                    .sum()
                    .sum()
                ),
                "sources": {str(p.relative_to(ROOT)): sha(p) for p in [a, b]},
                "metric_boundary_tests": "passed",
            },
            indent=2,
        )
    )
    print("EVIDENCE COMPLETE", OUT, flush=True)


if __name__ == "__main__":
    main()
