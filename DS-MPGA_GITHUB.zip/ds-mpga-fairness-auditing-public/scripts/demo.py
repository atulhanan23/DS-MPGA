"""Run a synthetic example without downloading person-level data."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import argparse, json
import numpy as np
import pandas as pd
from src.algorithms.ds_mpga import run_ds_mpga_v3_cached
from src.baselines.exact_random import enumerate_scores, uniform_random_reference
from src.rules.processing import classify


def fixture():
    a, b, c = np.indices((2, 2, 2)).reshape(3, -1)
    return pd.DataFrame(
        dict(
            a=np.tile(a, 20),
            b=np.tile(b, 20),
            c=np.tile(c, 20),
            prediction=np.tile(a & b, 20),
        )
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "outputs/demo")
    args = parser.parse_args()
    table = fixture()
    settings = json.loads((ROOT / "configs/search.json").read_text())
    result = run_ds_mpga_v3_cached(table, ["a", "b", "c"], random_state=7, **settings)
    rules, scores = enumerate_scores(table, ["a", "b", "c"])
    assert result["total_evaluation_requests"] == 5400
    assert result["actual_evaluations"] + result["cache_hits"] == 5400
    assert result["max_discrepancy_score"] <= np.nanmax(scores) + 1e-12
    assert result["min_discrepancy_score"] >= np.nanmin(scores) - 1e-12
    result["max_rule_type"] = classify(result["max_itemset"], ["a", "b"])
    result["exact_max_cv"], result["exact_min_cv"] = float(np.nanmax(scores)), float(
        np.nanmin(scores)
    )
    result["random_reference"] = uniform_random_reference(
        rules, scores, result["actual_evaluations"], 7
    )
    result["scope"] = (
        "Synthetic demonstration; not a reproduction of manuscript results."
    )
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "demo.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
