# Data preparation and access

No person-level modeling or prediction tables are included. Obtain the public datasets from their authoritative providers and review their terms:

- Adult: https://archive.ics.uci.edu/dataset/2/adult
- Statlog German Credit: https://archive.ics.uci.edu/dataset/144/statlog+german+credit+data
- COMPAS source analysis: https://github.com/propublica/compas-analysis
- AIF360 dataset preparation: https://github.com/Trusted-AI/AIF360/tree/main/aif360/data/raw/compas

Downloading today's files does not certify identity with the retained modeling inputs. The historical raw-to-prepared chain is incomplete. For the retained full drivers, use a separate input directory with this layout:

```text
retained-inputs/
  archive/imported/<any-subfolder>/
    adult_modeling_data.csv
    compas_modeling_data_fixed.csv
    german_modeling_data.csv
  prepared_data/ablation_corrected_v1/
    manifest.json
    <prediction tables named by the manifest>
```

Only one copy of each modeling filename may exist. Required target columns are `target_binary` plus `target` for Adult/German and `two_year_recid` for COMPAS. Favorable labels are >50K, good credit (original target 1), and no recidivism respectively. The preparation function checks those relationships and excludes outcome columns from predictors.

Subgroup columns must retain the original encodings:

- Adult: `sex`, `race`, `age_group`, `education`, `marital-status`, `hours_per_week_group`.
- COMPAS: `sex`, `race`, `age_cat`, `c_charge_degree`, `priors_count_group`.
- German: `checking_status`, `savings_status`, `employment`, `sex_group`, `age_group`, `duration_group`, `credit_amount_group`.

All other predictor columns, bin boundaries and category encodings must match the retained modeling tables. Do not infer them solely from this minimal schema. For example, COMPAS race code 0 denotes the pooled non-Caucasian group; it must not be relabeled as one narrower identity.

For references or sensitivity alone, also supply `results/final_evidence_v1/four_classifier_100seeds_all_details.csv` and every saved prediction file referenced there under `prepared_data/`. Predicted outcomes, true outcomes, subgroup attributes and source-row indices are required for row-level recomputation.

The saved aggregate evidence can be checked without those person-level files. New preparation, new bins, different training inputs or changed feature treatment constitute a new experiment version and must not silently replace manuscript values.
