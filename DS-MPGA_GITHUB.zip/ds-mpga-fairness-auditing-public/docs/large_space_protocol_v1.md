# Large rule-space experiment

Local plan recorded before results, 2 October 2026. No external preregistration.

Use controlled binary prediction tables with 8,192 observations, 16, 64, 256
and 1,024 attributes, and conjunctions of at most three distinct attributes.
The complete syntactic space has sum(C(d,k)*2^k, k=1..3) candidates. The
16-attribute condition is an exact-enumeration control; the larger conditions
test budgets far below the full space. Do not call enumeration infeasible solely
from dimension: report counts and the measured restricted enumeration time;
full enumeration is not attempted in the largest conditions.

Two synthetic prediction mechanisms use three known signal attributes:
conjunction (positive exactly when all three equal one) and parity (positive
when an odd number equal one). The eight signal patterns occur equally often.
Each nuisance attribute is balanced within every signal stratum, so it has
exactly zero marginal prediction disparity. Joint nuisance effects can still
occur in the finite sample. Permute columns and rows without supplying signal
identities to search algorithms. These are synthetic prediction functions, not
trained models or evidence about social groups.

Use ten independently generated tables per mechanism/dimension, and three
search seeds per table. Methods: unchanged canonical DS-MPGA search, random
search using the same random-rule initializer, and a dual-direction stochastic
hill climber with three independent chains per direction. Hill climbing uses
single-rule addition/removal/replacement moves, accepts non-worsening valid
scores, and restarts each chain every 100 visits. Set parameters before runs.

All methods receive 540, 1,800 and 5,400 objective-evaluation requests, from
prefixes of the same 5,400-request trajectory. Requests include duplicates and
invalid rules. Each method gets its own cache and the same prebuilt bit-mask
scorer, support 0.10 and nonempty complement. Report cache misses separately:
equal requests do not imply equal distinct-rule work or wall time. DS-MPGA
retains its separate maximum/minimum population output semantics; baselines
also allocate half their queries to each objective. Random initial proposals
share the canonical length/sampling/repair distribution, not uniform sampling
over the complete syntactic space. No method sees oracle scores or witnesses.

Reference: enumerate all rules on a fixed 16-attribute subset containing the
three signal attributes and 13 nuisance attributes. This informed subset is used
only for assessment and is disclosed. At dimension 16 it is the global exact
reference. At larger dimensions it yields a witnessed lower bound on the global
maximum; signed reference-minus-found gaps are not global regret estimates.
For conjunction data the planted rule has CV=1, proving the global maximum.
For parity data global maximum is bounded by the restricted exact score and 1.
For both, an independent nuisance singleton has CV=0, proving the global minimum.
Report global maximum regret exactly where certified; otherwise report lower
and upper regret bounds, and retain negative restricted-reference gaps.

Report ten-table means after averaging three search seeds within each table;
search seeds are not treated as independent datasets. Compare methods with
paired descriptive differences and table-level bootstrap intervals, with
resampling seed fixed, without selecting a favourable condition or declaring
universal superiority. Randomize method execution order reproducibly per table
and seed. Timings exclude shared mask construction and oracle computation, both
reported separately. They include proposal generation and cache lookups.

Validation: reconcile the fast scorer and canonical DS-MPGA outputs with the
original implementation on a complete small fixture; independently recompute
all returned rules; assert request budgets, cache identities and exact/bounded
regret. Preserve the original benchmark studies and update the manuscript only after
the full experiment completes. Unfavourable and null outcomes remain in the paper.
