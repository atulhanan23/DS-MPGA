# Reproducibility boundaries

The repository supports three distinct tasks:

1. A self-contained synthetic demonstration, unit tests and independent finite-space checks.
2. Verification and summary of included frozen aggregate/rule-level evidence.
3. New full experiments using separately supplied prepared inputs.

The third task is conditional on input availability. Historical raw provider snapshots, original Adult/German fixed-RF training indices and serialized trained models are not supplied. The old leakage-affected COMPAS table is not an input to this revision. The current classifier builders remove target-derived columns explicitly.

## Implementation map

| Manuscript component | Executable implementation |
|---|---|
| Complementary search and pooled migration | `src/algorithms/ds_mpga.py` |
| Cached/uncached and removal ablations | `run_ds_mpga_v3_ablation` in that module |
| Preparation and XGBoost | `scripts/run_xgboost.py` |
| LR, DT and RF | `scripts/run_remaining_classifiers.py` |
| Exact reference, distinct-work random and confirmation | `scripts/run_journal_extension.py` |
| Audit classification and restricted reference | `scripts/analyze_intersectional.py` |
| Conditional metrics and prediction checks | `scripts/build_final_evidence.py` |
| Sensitivity | `scripts/run_sensitivity.py` |
| Synthetic generator, random and hill climbing | `scripts/run_large_space.py` |
| Wilcoxon, rank-biserial and six Holm families | `scripts/final_statistics.py` |
| Main summaries and saved-evidence replay | `scripts/summarize_results.py`, `scripts/verify_results.py` |

The canonical engine preserves its stochastic repair calls, first-strict-improvement incumbents, parent sampling and final unevaluated offspring. Both directions share one random stream. Migration samples from newly formed populations and inserts the same shuffled pool prefix into every population of a direction, including leading positions that previously held elites. No ring migration or objective-to-objective migration is introduced.

The public `RuleCache` interface validates arbitrary user rules deterministically. It is an auxiliary inspection API; the historical search retains its stochastic evaluator. The historical engine exposes the actual ablation configurations; unsupported added baseline wrappers are not distributed.

## Full-run dependencies

Primary training produces the prediction tables and final evidence used by sensitivity and reference analyses. Fixed-prediction ablation needs its own manifest and retained inputs. The reference workflow produces exact/random and confirmation records before intersectional analysis. Scaling is synthetic and independent of personal data. Final statistics require completed primary, ablation and sensitivity families.

The included evidence does not represent a fresh full-pipeline run. New timing records are distinct from the validated historical timings. Running in a different environment can change timing and, in borderline model decisions, predictions; investigate discrepancies rather than force agreement.
