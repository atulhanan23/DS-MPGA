# Journal extension protocol

Written before running the new comparisons, 2 October 2026. This is a local
analysis plan, not an externally preregistered study. Existing results remain
unchanged. Journal readiness is assessed on evidence and contribution, not degree.

## Questions

1. How often does DS-MPGA attain the exact maximum and minimum in its stated
   finite rule space? What regret remains?
2. Does it improve on uniform sampling without replacement at the same number
   of distinct rule evaluations, counting invalid rules in both budgets?
3. Do discovery-selected rule disparities persist on disjoint confirmation rows?

## Design

Use all 1,200 validated prediction tables for exact optimality and random-search
comparisons. Enumerate every conjunction of 1–3 distinct attributes using observed
values, support >= 0.10, and a nonempty complement. The exact oracle applies the
same absolute favourable-prediction-rate difference as DS-MPGA. Enumeration is an
objective-matched reference, not a claimed reproduction of Fairpriori.

Random search samples syntactic rules uniformly without replacement, evaluates
the same number of distinct rules as that run's DS-MPGA cache misses (capped at
the full finite space), and returns both extrema. Use 20 random repetitions per
table, average within table before any paired summary. No equal wall-time claim
is made from precomputed oracle scores. Report full-space size alongside the
5,400 request budget; caching requests is not the same as distinct evaluations.

For an additional discovery/confirmation experiment, use the first 30 existing
split seeds for each of 12 dataset–classifier combinations (360 tables). Divide
each existing held-out prediction table 50/50 using a deterministic random
permutation seeded by 100000 + split seed. No outcome-dependent split or tuning.
Train predictions remain from the original fitted model. Run the unchanged
canonical DS-MPGA on discovery rows only with the original search seed; construct
candidate values on discovery only. Select exact and random-search rules on the
same discovery rows. Lock rules before inspecting confirmation rates.

Evaluate those fixed rules on all confirmation rows even if support drops below
0.10, record support violations separately, and leave empty-group rates undefined.
Do not reselect, filter by confirmation performance, or call these populations
independent across repeated splits. Compare signed and absolute rate differences;
report their discovery-to-confirmation changes descriptively. The original
pre-split category-vocabulary limitation remains; this extension is conditional
confirmation on a disjoint subset of saved predictions, not new external data.

## Validation and reporting

Validate the vectorized oracle against independent row-mask calculations on a
synthetic complete rule space and sampled benchmark rules. Verify DS-MPGA extrema
lie within exact bounds. Save source hashes, selected rules, row-index hashes,
budgets, seeds, undefined values and checkpointed per-table outputs.

Primary outputs: exact-hit rate (tolerance 1e-12), max and min regret, mean paired
DS-MPGA minus random performance, and confirmation changes. No new significance
tests treating 20 repetitions or overlapping test splits as independent subjects.
The manuscript must include unfavourable and null results. No algorithm changes
will be tuned on confirmation outcomes. A target-journal decision remains an
study-team decision after reviewing these outcomes.
