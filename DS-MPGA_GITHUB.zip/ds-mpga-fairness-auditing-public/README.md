# DS-MPGA

**Complementary subgroup-disparity discovery with empirical validation.**

DS-MPGA searches short conjunctions over saved binary classifier predictions. It returns a rule with a large absolute subgroup-versus-complement favorable-prediction-rate difference (CV), and a complementary rule with a small difference. Three genetic populations operate within each direction; migration stays within a direction, while a canonical evaluation cache is shared across the run.

The repository accompanies *DS-MPGA: Interpretable Search-Based Fairness Testing for Subgroup Disparities*. The contribution is the integrated auditing and validation workflow. A small minimum does not certify fairness, and a lower heuristic maximum can reflect missed discovery. The experiments do not establish an optimization advantage from the tested population or migration choices.

## Contents

```text
configs/                 Recorded search settings and seed sets
data/                    Input schemas and dataset preparation instructions
src/algorithms/          Retained DS-MPGA implementation
src/rules/               Rule decoding and audit/context classification
src/evaluation/          Support, cache, confirmation and conditional metrics
src/baselines/           Exact and random references
src/statistics/          Paired Wilcoxon and rank-biserial calculation
src/preprocessing/      Retained preparation entry point and limitations
scripts/                 Experiment drivers, demonstration and evidence checks
results/validated/       Frozen aggregate and rule-level research evidence
tests/                   Core semantic and accounting tests
docs/                    Method mapping and reproducibility boundaries
supplementary/           Article supplement and required figures
```

## Environment

Use Python 3.12 and an isolated environment:

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

The pinned versions record the research environment. They are not a claim that every platform or package mirror has been tested. Record any substitutions and treat outputs produced under changed environments as new runs. PDF compilation additionally requires pdfLaTeX and BibTeX.

## Quick example and tests

From the repository root:

```bash
python -m unittest discover -s tests -v
python scripts/demo.py
python scripts/verify_results.py
python scripts/summarize_results.py
python scripts/regenerate_retained_plots.py
```

The example creates a synthetic 160-row table and performs one 5,400-request search, then compares it with exact and random references. It needs no downloads. Outputs go to `outputs/demo/`. This is a demonstration, not a reproduction of 1,200 classifier experiments.

The evidence checker validates archived counts and replays the six Holm correction families. The summary command regenerates descriptive CSV tables under `outputs/summaries/`. Neither command retrains models or reruns historical timing experiments. Standard deviations use the sample convention.

## Full experiments

Read `data/README.md` first. Raw person-level data and saved prediction tables are deliberately absent. Full drivers require separately supplied prepared inputs. Public download links alone cannot recreate missing historical preprocessing provenance.

```bash
python scripts/run_full.py --input-root /path/to/retained-inputs --run-id study-001 --family all
```

Individual families can be selected with `--family primary`, `ablation`, `sensitivity`, `references`, or `scaling`. For a completely synthetic full scaling run:

```bash
python scripts/run_full.py --input-root data --run-id scaling-001 --family scaling
```

The wrapper checks required inputs, copies code and inputs into a new `outputs/full/<run-id>/` workspace, and runs the retained drivers there. It refuses an existing run identifier. Native drivers checkpoint work; resuming an interrupted workspace requires rerunning the failed driver there with unchanged inputs and configuration. The original `results/validated/` files are never used as output targets.

The primary family fits LR, DT, RF and XGBoost across three datasets and 100 matched split/search seeds, preserving the original split and model settings. The other families cover fixed-prediction ablations, sensitivity, exact/random references, locked-rule confirmation, rule classification and synthetic scaling. See `docs/reproducibility.md` for dependencies and unavailable inputs.

## Results and manuscript tables

`results/validated_manifest.json` provides file hashes for the included evidence files. Detailed full-precision values remain in the CSV evidence rather than being reconstructed from rounded printed numbers.

The article uses these retained table bodies; `summarize_results.py` recalculates the main descriptive aggregates from the included records. The supplement contains Tables S1–S13 and Figures S1–S3, including all moved displays. Full selected-rule, recurrence, sensitivity and statistical listings accompany it as CSV files.

The complete manuscript source is distributed separately. This repository contains the study implementation, experiment drivers, validation utilities and frozen aggregate evidence.

## Computational requirements and scope

The demonstration is CPU-only and small. Full classifier and search runs may take many hours and produce many prediction files; random forests and XGBoost use all available CPU threads in the retained configuration. Synthetic scaling uses 8,192 rows and up to 1,024 binary attributes. No measured peak-memory claim or cross-platform timing guarantee is made.

This package preserves saved evidence and executable methodology but does not claim complete raw-data-to-publication reproducibility. Historical Adult/German ablation training indices, provider snapshots and serialized historical models are unavailable. The primary category vocabulary is formed before splitting, as disclosed. Internal confirmation is not external validation. PSO, GWO and an Apriori baseline are not implemented in this repository.

## Citation

Use `CITATION.cff` for the manuscript title and authors. Publication details and a DOI have not yet been assigned.

## License

Copyright remains with the authors. No permission to reuse, modify or redistribute the software is granted unless a separate license is added by the authors.
